# Up Next 1.3.0.1 Xbox workaround (user-requested no-op)
# This shim stays alive so Kodi can start and stop the service cleanly.
# It does not intercept playback, change settings or make network requests.
import xbmc

xbmc.log('Up Next disabled (Xbox compatibility workaround)', xbmc.LOGINFO)
monitor = xbmc.Monitor()
monitor.waitForAbort()
