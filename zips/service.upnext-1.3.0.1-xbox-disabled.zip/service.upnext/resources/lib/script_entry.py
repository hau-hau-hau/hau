# Up Next automatic next-episode feature intentionally disabled.
import xbmc
xbmc.log('Up Next action suppressed by Xbox workaround', xbmc.LOGINFO)
