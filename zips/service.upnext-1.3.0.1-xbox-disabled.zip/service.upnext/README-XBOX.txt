UP NEXT 1.3.0.1 - XBOX DISABLED WORKAROUND

This is NOT an official Up Next release. It is a minimal replacement add-on
that retains the addon ID service.upnext so Kodi's add-on dependency checks
continue to pass, but does NOT offer automatic next-episode functionality.

Only install if you do NOT want to use Up Next and it is causing an error
at Kodi startup. The package is intended for Kodi 19+ with Python 3.

To restore normal functionality, install the official Up Next add-on from a
trusted Kodi repository, selecting the official version if needed.

Source: independently written Python shim; no hidden or obfuscated code.
No third-party network calls or telemetry.
