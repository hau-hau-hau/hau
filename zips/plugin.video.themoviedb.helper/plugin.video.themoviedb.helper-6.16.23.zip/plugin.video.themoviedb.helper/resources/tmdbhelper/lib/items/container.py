from jurialmunkey.parser import boolean
from jurialmunkey.ftools import cached_property
from tmdbhelper.lib.addon.consts import NO_UNAIRED_LABEL
from tmdbhelper.lib.addon.plugin import get_setting, executebuiltin, get_localized
from tmdbhelper.lib.api.contains import CommonContainerAPIs
from tmdbhelper.lib.addon.logger import TimerList


# --- Webshare FULL filter custom mod (6.16.10 media confidence labels) ---
# Hides movie list items that Webshare/YAWsP cannot find.
# 6.16.6: API-check strict: derive movie year from premiered/released dates and require exact year when available.
# Safe behaviour: if YAWsP credentials/token/API are unavailable, it FAILS OPEN
# so TMDb lists still display normally instead of disappearing.
_WEBSHARE_AVAIL_CACHE = {}
_WEBSHARE_META_CACHE = {}
_WEBSHARE_CACHE_TTL = 600
_WS_STOPWORDS = set(('the', 'a', 'an', 'and', 'of', 'to', 'in', 'on', 'for', 'cz', 'sk', 'en', 'dabing', 'titulky'))


def _ws_norm_text(value):
    try:
        import unicodedata
        value = str(value or '').lower()
        value = unicodedata.normalize('NFKD', value)
        value = ''.join(c for c in value if not unicodedata.combining(c))
        value = value.replace('&', ' and ')
        import re
        value = re.sub(r'[^a-z0-9]+', ' ', value)
        return ' '.join(value.split())
    except Exception:
        return str(value or '').lower().strip()




def _ws_is_latinish(value):
    """True when a title is useful for Webshare text search.

    TMDb original_title can be Hangul/Japanese/Cyrillic/etc. Webshare uploads are
    usually stored under international/English or local CZ/SK titles, so non-Latin
    original titles should not be the primary query.
    """
    value = str(value or '').strip()
    if not value:
        return False
    import re
    latin = re.findall(r'[A-Za-z0-9]', value)
    if len(latin) >= 2:
        return True
    return False

def _ws_split_num_suffix(norm_title):
    """Return (base_title, number_suffix) for titles like 'zootropolis 2'."""
    import re
    m = re.match(r'^(.*?)(?:\s+)(\d{1,2})$', norm_title or '')
    if not m:
        return norm_title, ''
    return m.group(1).strip(), m.group(2).strip()


def _ws_aliases_for_title(title):
    """Hand aliases for titles that Webshare commonly stores under different names.
    Also keeps sequel numbers, e.g. Zootropolis 2 -> Zootopia 2 / Mesto zvirat 2.
    """
    aliases = {
        'zootropolis': ['zotropolis', 'zo tropolis', 'zootopia', 'mesto zvirat', 'mesto zvířat'],
        'zootopia': ['zootropolis', 'zotropolis', 'zo tropolis', 'mesto zvirat', 'mesto zvířat'],
        'zotropolis': ['zootropolis', 'zo tropolis', 'zootopia', 'mesto zvirat', 'mesto zvířat'],
        'zo tropolis': ['zootropolis', 'zotropolis', 'zootopia', 'mesto zvirat', 'mesto zvířat'],
        'mesto zvirat': ['zootropolis', 'zotropolis', 'zo tropolis', 'zootopia', 'mesto zvířat'],
        'parazit': ['parasite', 'gisaengchung', '기생충'],
        'parasite': ['parazit', 'gisaengchung', '기생충'],
        'gisaengchung': ['parasite', 'parazit', '기생충'],
        'gisaengchung 2019': ['parasite 2019', 'parazit 2019'],
    }
    norm = _ws_norm_text(title)
    base, suffix = _ws_split_num_suffix(norm)
    out = []
    for alias in aliases.get(norm, []):
        out.append(alias)
    for alias in aliases.get(base, []):
        out.append(f'{alias} {suffix}' if suffix else alias)
        # For Webshare entries that omit sequel number from localized title, keep base alias too.
        if suffix:
            out.append(alias)
    return out


def _ws_query_variants(title, year=None):
    title = str(title or '').strip()
    year = str(year or '').strip()
    if not title:
        return []
    variants = []

    def add(q):
        q = ' '.join(str(q or '').replace('.', ' ').replace('-', ' ').split())
        if q and q not in variants:
            variants.append(q)

    add(f'{title} {year}' if year else title)
    add(title)
    add(title.replace(':', ''))
    add(title.replace('&', 'and'))
    add(title.replace(' and ', ' & '))
    add(title.replace('-', ''))
    add(title.replace('-', ' '))

    for alias in _ws_aliases_for_title(title):
        add(f'{alias} {year}' if year else alias)
        add(alias)

    return variants[:12]



def _ws_unique_titles(*values):
    out = []
    seen = set()
    for value in values:
        if isinstance(value, (list, tuple, set)):
            for v in value:
                n = _ws_norm_text(v)
                if n and n not in seen:
                    seen.add(n); out.append(str(v))
        else:
            n = _ws_norm_text(value)
            if n and n not in seen:
                seen.add(n); out.append(str(value))
    return out


def _ws_listitem_titles(li):
    """Return (primary_search_title, alt_titles) for Webshare checks.

    6.16.18: prefer a Latin/international title for Webshare searches. TMDb can
    expose original_title in the native script (e.g. Parasite = 기생충), while
    Webshare uploads usually use the international/English title. Localised SK/CZ
    title stays available as fallback and UI/plot language is untouched.
    """
    labels = getattr(li, 'infolabels', None) or {}
    props = getattr(li, 'infoproperties', None) or {}
    local_title = labels.get('title') or getattr(li, 'label', '') or ''
    original_title = (
        labels.get('originaltitle') or
        props.get('originaltitle') or
        props.get('original_title') or
        props.get('tvshow.originaltitle') or
        ''
    )
    en_title = (
        props.get('en_title') or
        props.get('en_tvshowtitle') or
        props.get('english_title') or
        props.get('international_title') or
        ''
    )
    sort_title = labels.get('sorttitle') or props.get('sorttitle') or ''

    # Known local/native aliases can reveal the international title even when
    # TMDb does not expose en_title in this list item.
    alias_titles = []
    for t in (original_title, en_title, sort_title, local_title):
        alias_titles.extend(_ws_aliases_for_title(t))

    candidates = _ws_unique_titles(en_title, original_title, sort_title, local_title, alias_titles)
    latin_candidates = [t for t in candidates if _ws_is_latinish(t)]
    search_title = latin_candidates[0] if latin_candidates else (candidates[0] if candidates else local_title)
    alt_titles = _ws_unique_titles(search_title, candidates)
    return search_title, alt_titles

def _ws_query_variants_many(titles, year=None):
    """Build Webshare search queries for all known title variants.

    6.16.16 fix: previous build accidentally recursed and fell into the
    fail-open path, so unavailable/wrong titles could pass.  This now uses
    the real per-title variant generator and keeps original/English title
    before localised SK/CZ fallback.
    """
    variants = []
    for title in _ws_unique_titles(titles):
        for q in _ws_query_variants(title, year):
            if q and q not in variants:
                variants.append(q)
    return variants[:36]


def _ws_title_score_many(name, titles, year=None):
    return max([_ws_title_score(name, title, year) for title in _ws_unique_titles(titles)] or [0])

def _ws_result_years(norm_name):
    import re
    return re.findall(r'\b(?:19|20)\d{2}\b', norm_name or '')


def _ws_title_score(name, title, year=None):
    """Real strict movie matcher, modelled after the YAWsP stream picker.
    A result is accepted only when title/alias is strong enough AND any explicit
    year in the filename is not a different movie year. This removes cases like
    'The Menu 2014' while still allowing 'Zootopia 2' aliases.
    """
    n = _ws_norm_text(name)
    t = _ws_norm_text(title)
    y = str(year or '').strip()
    if not n or not t:
        return 0

    years_in_name = _ws_result_years(n)
    # Hard reject if a filename declares a different movie year.
    if y and years_in_name and y not in years_in_name:
        return 0

    candidates = [t] + [_ws_norm_text(a) for a in _ws_aliases_for_title(title)]
    candidates = [c for c in candidates if c]

    best = 0
    for cand in candidates:
        score = 0
        words_all = [w for w in cand.split() if len(w) >= 2]
        words_sig = [w for w in words_all if w not in _WS_STOPWORDS and len(w) >= 3]

        # Exact normalized phrase/alias is strongest.
        if cand in n:
            score += 75
        else:
            if not words_sig:
                continue
            # Match by whole tokens, not substring, to avoid broad false positives.
            n_words = set(n.split())
            hits = sum(1 for w in words_sig if w in n_words)
            required = len(words_sig) if len(words_sig) <= 2 else len(words_sig) - 1
            if hits < required:
                continue
            score += 35 + (hits * 8)

            # One-word/generic titles are dangerous unless year or sequel number confirms it.
            if len(words_sig) <= 1:
                has_number = any(w.isdigit() for w in words_all)
                if not has_number and y and y not in years_in_name and cand not in n:
                    continue

        if y and y in years_in_name:
            score += 30
        elif y and not years_in_name:
            # Ultra strict: if target year exists but filename has no year, allow only very strong exact phrase/alias hits.
            if cand not in n:
                continue
            score -= 15

        # Sequel/number consistency: if title ends with 2/3/etc, result should contain it.
        _base, suffix = _ws_split_num_suffix(cand)
        if suffix:
            if suffix in n.split():
                score += 20
            else:
                continue

        bad_words = ('sample', 'trailer', 'cam', 'hdcam', 'ts', 'telesync', 'gameplay', 'game', 'documentary', 'bonus')
        if any(b in n.split() for b in bad_words):
            continue

        best = max(best, score)

    return best


def _ws_name_matches(name, title, year=None):
    return _ws_title_score(name, title, year) >= 95



def _ws_to_dict(xml, skip=()):
    """Small XML -> dict helper for Webshare file_info metadata."""
    result = {}
    try:
        for e in xml:
            if e.tag in skip:
                continue
            value = e.text if len(list(e)) == 0 else _ws_to_dict(e, skip)
            if e.tag in result:
                if isinstance(result[e.tag], list):
                    result[e.tag].append(value)
                else:
                    result[e.tag] = [result[e.tag], value]
            else:
                result[e.tag] = value
    except Exception:
        pass
    return result


def _ws_map_language_token(value):
    """Normalize language tokens from Webshare/API/MediaInfo/filename.

    CZ aliases: cz, cs, cze, ces, czech, cesky/česky, cestina/čeština
    SK aliases: sk, svk, slk, slovak, slovensky/slovenský, slovencina/slovenčina
    Also maps common other languages for compact labels such as EN/ES/DE/FR.
    """
    value = _ws_norm_text(value)
    if not value:
        return ''
    aliases = [x for x in re.split(r'[/,;| ]+', value) if x] + [value]
    for token in aliases:
        if token in ('cz', 'cs', 'cze', 'ces', 'czech', 'czechia', 'cesky', 'ceske', 'cestina') or 'czech' in token or 'cesk' in token:
            return 'CZ'
        if token in ('sk', 'svk', 'slk', 'slo', 'slovak', 'slovensky', 'slovenske', 'slovencina') or 'slovak' in token or 'slovensk' in token:
            return 'SK'
        if token in ('en', 'eng', 'english', 'anglicky', 'anglictina') or 'english' in token:
            return 'EN'
        if token in ('es', 'esp', 'spa', 'spanish', 'espanol', 'spanelsky', 'spanielsky') or 'spanish' in token:
            return 'ES'
        if token in ('de', 'ger', 'deu', 'german', 'nemecky', 'nemcina') or 'german' in token:
            return 'DE'
        if token in ('fr', 'fre', 'fra', 'french', 'francuzsky', 'francouzsky') or 'french' in token:
            return 'FR'
        if token in ('it', 'ita', 'italian', 'italsky', 'taliansky') or 'italian' in token:
            return 'IT'
        if token in ('pl', 'pol', 'polish', 'polsky') or 'polish' in token:
            return 'PL'
        if token in ('hu', 'hun', 'hungarian', 'madarsky') or 'hungarian' in token:
            return 'HU'
        if token in ('ru', 'rus', 'russian', 'rusky') or 'russian' in token:
            return 'RU'
        if token in ('jp', 'jpn', 'ja', 'japanese', 'japonsky') or 'japanese' in token:
            return 'JP'
        if token in ('ko', 'kor', 'korean', 'korejsky') or 'korean' in token:
            return 'KO'
    return ''


def _ws_collect_audio_langs_from_info(info):
    langs = []
    def visit(obj):
        if isinstance(obj, dict):
            # Stream/audio containers usually carry keys such as language/lang/title/name.
            for k, v in obj.items():
                kl = str(k).lower()
                if kl in ('language', 'lang', 'language_string', 'title', 'name', 'audio_language', 'audio_lang'):
                    mapped = _ws_map_language_token(v)
                    if mapped:
                        langs.append(mapped)
                visit(v)
        elif isinstance(obj, list):
            for x in obj:
                visit(x)
    try:
        visit(info or {})
    except Exception:
        pass
    return set(langs)


def _ws_collect_subtitle_langs_from_info(info):
    langs = []
    def visit(obj, inside_sub=False):
        if isinstance(obj, dict):
            for k, v in obj.items():
                kl = str(k).lower()
                next_sub = inside_sub or kl in ('text', 'subtitle', 'subtitles', 'sub', 'subs')
                if next_sub and kl in ('language', 'lang', 'language_string', 'title', 'name', 'subtitle_language', 'subtitle_lang'):
                    mapped = _ws_map_language_token(v)
                    if mapped:
                        langs.append(mapped)
                visit(v, next_sub)
        elif isinstance(obj, list):
            for x in obj:
                visit(x, inside_sub)
    try:
        visit(info or {}, False)
    except Exception:
        pass
    return set(langs)



def _ws_duration_seconds_from_info(info):
    if not info:
        return 0
    def walk(obj):
        if isinstance(obj, dict):
            yield obj
            for v in obj.values():
                for x in walk(v):
                    yield x
        elif isinstance(obj, list):
            for v in obj:
                for x in walk(v):
                    yield x
    try:
        for d in walk(info):
            for key in ('duration', 'length', 'runtime', 'duration_string', 'playtime'):
                val = d.get(key) if isinstance(d, dict) else None
                if not val:
                    continue
                txt = str(val).strip()
                try:
                    if ':' in txt:
                        parts = [float(x) for x in txt.split(':') if x != '']
                        if len(parts) == 3:
                            sec = int(parts[0] * 3600 + parts[1] * 60 + parts[2])
                        elif len(parts) == 2:
                            sec = int(parts[0] * 60 + parts[1])
                        else:
                            continue
                    else:
                        num = float(__import__('re').sub(r'[^0-9.]', '', txt) or 0)
                        if num <= 0:
                            continue
                        sec = int(num * 60) if num < 600 else int(num)
                        if sec > 100000:
                            sec = int(sec / 1000)
                    if sec >= 20 * 60:
                        return sec
                except Exception:
                    pass
    except Exception:
        pass
    return 0


def _ws_duration_status(info, runtime_seconds, tolerance_minutes=8):
    if not runtime_seconds:
        return 'ok'
    got = _ws_duration_seconds_from_info(info)
    if not got:
        return 'noinfo'
    tolerance = max(int(tolerance_minutes * 60), int(runtime_seconds * 0.08))
    return 'ok' if abs(int(got) - int(runtime_seconds)) <= tolerance else 'bad'


def _ws_extract_runtime_seconds_from_listitem(li):
    try:
        labels = getattr(li, 'infolabels', None) or {}
        props = getattr(li, 'infoproperties', None) or {}
        for key in ('duration', 'runtime', 'db_runtime'):
            val = labels.get(key) or props.get(key)
            if not val:
                continue
            txt = str(val).strip()
            if ':' in txt:
                parts = [float(x) for x in txt.split(':') if x != '']
                if len(parts) == 3:
                    sec = int(parts[0]*3600 + parts[1]*60 + parts[2])
                elif len(parts) == 2:
                    sec = int(parts[0]*60 + parts[1])
                else:
                    continue
            else:
                num = float(__import__('re').sub(r'[^0-9.]', '', txt) or 0)
                if num <= 0:
                    continue
                sec = int(num * 60) if num < 600 else int(num)
            if sec >= 20 * 60:
                return sec
    except Exception:
        pass
    return 0

def _ws_file_info(ident, token, headers):
    """Read real Webshare file_info metadata when available."""
    if not ident or not token:
        return None
    try:
        import requests
        from xml.etree import ElementTree as ET
        for data in ({'ident': ident, 'wst': token}, {'ident': ident, 'wst': token, 'maybe_removed': 'true'}):
            response = requests.post('https://webshare.cz/api/file_info/', data=data, headers=headers, timeout=4)
            xml = ET.fromstring(response.content)
            if xml.findtext('status') == 'OK':
                return _ws_to_dict(xml)
    except Exception:
        return None
    return None


def _ws_detect_stream_meta_from_name(name, info=None):
    """Extract display metadata.

    Real Webshare/API media metadata is preferred. If metadata is unavailable,
    filename parsing is used as a fallback and marked as uncertain using
    audio_confident/subs_confident flags.
    """
    import re
    raw = str(name or '')
    n = _ws_norm_text(raw)
    tokens = set(n.split())

    real_audio = _ws_collect_audio_langs_from_info(info)
    real_subs = _ws_collect_subtitle_langs_from_info(info)

    audio_guess = set()
    subs_guess = set()

    # Audio / dub language markers from filename fallback
    if tokens.intersection(set(('cz', 'cs', 'cze', 'ces', 'czech', 'cesky', 'ceske', 'cestina', 'dabingcz', 'czdabing'))):
        audio_guess.add('CZ')
    if tokens.intersection(set(('sk', 'svk', 'slk', 'slo', 'slovak', 'slovensky', 'slovenske', 'slovencina', 'dabingsk', 'skdabing'))):
        audio_guess.add('SK')
    if tokens.intersection(set(('en', 'eng', 'english', 'anglicky', 'anglictina'))):
        audio_guess.add('EN')
    if tokens.intersection(set(('es', 'esp', 'spa', 'spanish', 'espanol', 'spanelsky', 'spanielsky'))):
        audio_guess.add('ES')
    if tokens.intersection(set(('de', 'ger', 'deu', 'german', 'nemecky', 'nemcina'))):
        audio_guess.add('DE')
    if tokens.intersection(set(('fr', 'fre', 'fra', 'french', 'francuzsky', 'francouzsky'))):
        audio_guess.add('FR')
    if tokens.intersection(set(('it', 'ita', 'italian', 'italsky', 'taliansky'))):
        audio_guess.add('IT')
    if tokens.intersection(set(('jp', 'jpn', 'ja', 'japanese', 'japonsky'))):
        audio_guess.add('JP')

    compact = re.sub(r'[^a-z0-9]+', '', n)
    if 'czdab' in compact or 'dabingcz' in compact:
        audio_guess.add('CZ')
    if 'skdab' in compact or 'dabingsk' in compact:
        audio_guess.add('SK')

    # Subtitle markers - only CZ/SK requested. Explicit markers only.
    if re.search(r'\b(cz|cs|cze|ces|czech|ceske|cesky|cestina)\s*(tit|titulky|subs|subtitles)\b', n) or 'cztit' in compact or 'cztitulky' in compact or 'czsub' in compact or 'czsubs' in compact:
        subs_guess.add('CZ')
    if re.search(r'\b(sk|svk|slk|slo|slovak|slovenske|slovensky|slovencina)\s*(tit|titulky|subs|subtitles)\b', n) or 'sktit' in compact or 'sktitulky' in compact or 'sksub' in compact or 'sksubs' in compact:
        subs_guess.add('SK')

    audio = real_audio or audio_guess
    subs = real_subs or subs_guess

    quality_score = 0
    if re.search(r'\b(2160p|4k|uhd)\b', n):
        quality_score = 4
    elif '1080p' in tokens or 'fullhd' in tokens:
        quality_score = 3
    elif '720p' in tokens or 'hd' in tokens:
        quality_score = 2
    elif '480p' in tokens:
        quality_score = 1

    return {
        'audio': audio,
        'subs': subs,
        'audio_real': real_audio,
        'audio_guess': audio_guess,
        'subs_real': real_subs,
        'subs_guess': subs_guess,
        'audio_confident': bool(real_audio),
        'subs_confident': bool(real_subs),
        'quality_score': quality_score
    }


def _ws_search_meta(title, year=None, alt_titles=None, runtime_seconds=0):
    """Return availability + confidence-labelled language/subtitle metadata.

    Search response proves availability. file_info is then queried for matched
    results to get real media metadata. If real metadata is missing, filename
    fallback is still used but marked uncertain (DAB?/TIT?).
    """
    import time
    key = f'{_ws_norm_text(title)}|{_ws_norm_text(alt_titles)}|{year or ""}|{runtime_seconds or 0}|metalabels61622'
    now = time.time()
    cached = _WEBSHARE_META_CACHE.get(key)
    if cached and now - cached[0] < _WEBSHARE_CACHE_TTL:
        return cached[1]

    meta = {
        'available': False,
        'audio_real': set(), 'audio_guess': set(),
        'subs_real': set(), 'subs_guess': set(),
        'best_quality': 0
    }

    try:
        import xbmcaddon
        yawsp = xbmcaddon.Addon('plugin.video.yawsp')
        token = yawsp.getSetting('token')
        if not token:
            meta['available'] = True  # fail open, but no fake labels
            _WEBSHARE_META_CACHE[key] = (now, meta)
            return meta
    except Exception:
        # API/search failure for this item: do not invent availability or labels.
        # Global token/addon failures still fail-open above to avoid an empty UI.
        meta['available'] = False
        _WEBSHARE_META_CACHE[key] = (now, meta)
        return meta

    try:
        import requests
        from xml.etree import ElementTree as ET
        headers = {'User-Agent': 'Mozilla/5.0', 'Referer': 'https://webshare.cz'}
        checked_info = 0
        seen = set()
        for q in _ws_query_variants_many(_ws_unique_titles(title, alt_titles), year):
            response = requests.post('https://webshare.cz/api/search/', data={
                'what': q,
                'category': 'video',
                'sort': 'rating',
                'limit': '20',
                'offset': '0',
                'wst': token,
                'maybe_removed': 'true'
            }, headers=headers, timeout=4)
            xml = ET.fromstring(response.content)
            if xml.findtext('status') != 'OK':
                continue
            for f in xml.iter('file'):
                name = f.findtext('name') or ''
                ident = f.findtext('ident') or name
                if ident in seen:
                    continue
                seen.add(ident)
                # 6.16.23: for movies, only accept Webshare hits that include the requested year
                # in the upload filename. This keeps TMDb availability in sync with YAWsP 0.5.7
                # and removes no-year false positives. Series are not checked here.
                if year and not __import__('re').search(r'\b%s\b' % __import__('re').escape(str(year)), name or ''):
                    continue
                score = _ws_title_score_many(name, _ws_unique_titles(title, alt_titles), year)
                if score < 95:
                    continue
                meta['available'] = True

                # Pull real media metadata for the first few strong matches only,
                # keeping list loading reasonable.
                info = None
                if checked_info < 5 and f.findtext('ident'):
                    info = _ws_file_info(f.findtext('ident'), token, headers)
                    checked_info += 1
                if _ws_duration_status(info, runtime_seconds) == 'bad':
                    continue
                sm = _ws_detect_stream_meta_from_name(name, info)
                meta['audio_real'].update(sm.get('audio_real') or set())
                meta['audio_guess'].update(sm.get('audio_guess') or set())
                meta['subs_real'].update(sm.get('subs_real') or set())
                meta['subs_guess'].update(sm.get('subs_guess') or set())
                meta['best_quality'] = max(meta.get('best_quality') or 0, sm.get('quality_score') or 0)
        _WEBSHARE_META_CACHE[key] = (now, meta)
        return meta
    except Exception:
        meta['available'] = True
        _WEBSHARE_META_CACHE[key] = (now, meta)
        return meta


def _ws_sorted_langs(values, order=('CZ', 'SK', 'EN')):
    return sorted(values or [], key=lambda x: {v: i for i, v in enumerate(order)}.get(x, 99))


def _ws_format_movie_badge(year='', meta=None):
    """Smart compact movie badge with final polished language logic.

    UX rules:
    1) Confirmed CZ/SK audio from metadata wins: show only CZ, SK, or CZ/SK.
    2) If no confirmed CZ/SK audio but confirmed CZ/SK subtitles exist, show
       confirmed audio languages +tit (e.g. EN +tit, ES/EN +tit). If no audio
       metadata is present, fall back to EN +tit.
    3) If no CZ/SK audio/subtitles but other confirmed audio metadata exists,
       show those languages (EN, ES/EN, JP...).
    4) If nothing confirmed but filename hints CZ/SK, show ?CZ?, ?SK?, ?CZ/SK?.
    5) If nothing useful is known, show only the year.
    """
    parts = []
    if year:
        parts.append(str(year))
    meta = meta or {}

    audio_real = set(meta.get('audio_real') or [])
    audio_guess = set(meta.get('audio_guess') or []) - audio_real
    subs_real = set(meta.get('subs_real') or [])
    subs_guess = set(meta.get('subs_guess') or []) - subs_real

    czsk_audio_real = {x for x in audio_real if x in ('CZ', 'SK')}
    czsk_subs_real = {x for x in subs_real if x in ('CZ', 'SK')}
    other_audio_real = {x for x in audio_real if x not in ('CZ', 'SK')}
    czsk_uncertain = {x for x in (audio_guess | subs_guess) if x in ('CZ', 'SK')}

    media = ''
    if czsk_audio_real:
        # Confirmed CZ/SK dubbing is the most useful info. Do not add EN/subtitles.
        media = '/'.join(_ws_sorted_langs(czsk_audio_real, order=('CZ', 'SK')))
    elif czsk_subs_real:
        # Confirmed CZ/SK subtitles: show real audio languages +tit.
        audio_label = '/'.join(_ws_sorted_langs(other_audio_real, order=('EN', 'ES', 'DE', 'FR', 'IT', 'JP', 'KO', 'CN', 'PL', 'HU', 'RU'))) or 'EN'
        media = f'{audio_label} +tit'
    elif other_audio_real:
        # No local audio/subtitles, but metadata contains confirmed audio language(s).
        media = '/'.join(_ws_sorted_langs(other_audio_real, order=('EN', 'ES', 'DE', 'FR', 'IT', 'JP', 'KO', 'CN', 'PL', 'HU', 'RU')))
    elif czsk_uncertain:
        # Filename-only hint. Do not claim whether it is audio or subtitles.
        hint = '/'.join(_ws_sorted_langs(czsk_uncertain, order=('CZ', 'SK')))
        media = f'?{hint}?'

    if media:
        parts.append(media)

    return ' • '.join(parts)

def _ws_apply_movie_badge(li):
    """Append [year | audio | CZ/SK tit] beside movie titles."""
    try:
        mediatype = (li.infolabels or {}).get('mediatype') or ''
        if mediatype != 'movie':
            return li
        title = (li.infolabels or {}).get('title') or li.label or ''
        search_title, alt_titles = _ws_listitem_titles(li)
        year = _ws_extract_year_from_listitem(li)
        runtime_seconds = _ws_extract_runtime_seconds_from_listitem(li)
        meta = _ws_search_meta(search_title, year, alt_titles=alt_titles, runtime_seconds=runtime_seconds)
        badge = _ws_format_movie_badge(year, meta)
        if not badge:
            return li
        # Avoid double-appending after refresh/reuse.
        import re
        clean_label = re.sub(r'\s*\[[^\]]*(?:19|20)\d{2}[^\]]*\]\s*$', '', li.label or title).strip()
        li.label = f'{clean_label} [COLOR=ffaaaaaa][{badge}][/COLOR]'
        return li
    except Exception:
        return li

def _ws_search_available(title, year=None, alt_titles=None, runtime_seconds=0):
    return bool((_ws_search_meta(title, year, alt_titles=alt_titles, runtime_seconds=runtime_seconds) or {}).get('available'))


def _ws_extract_year_from_listitem(li):
    """Get the TMDb movie year reliably.

    Search/result lists in TMDb Helper do not always populate the numeric
    'year' infolabel, but they usually have a date such as premiered/releasedate
    (the date shown at the bottom of the Kodi skin).  Without this, a generic
    title like 'The Menu' can incorrectly pass because Webshare has *some*
    'The Menu' file.
    """
    import re
    labels = getattr(li, 'infolabels', None) or {}
    props = getattr(li, 'infoproperties', None) or {}

    for key in ('year', 'premiered', 'releasedate', 'aired', 'firstaired', 'date', 'originalyear'):
        val = labels.get(key) or props.get(key)
        if val:
            m = re.search(r'\b(?:19|20)\d{2}\b', str(val))
            if m:
                return m.group(0)

    # Some TMDb paths include year/date/query params; use as a last resort.
    for val in (getattr(li, 'url', '') or '', getattr(li, 'label', '') or ''):
        m = re.search(r'\b(?:19|20)\d{2}\b', str(val))
        if m:
            return m.group(0)
    return ''


def _ws_should_hide_listitem(li):
    try:
        mediatype = (li.infolabels or {}).get('mediatype') or ''
        if mediatype != 'movie':
            return False
        search_title, alt_titles = _ws_listitem_titles(li)
        year = _ws_extract_year_from_listitem(li)
        runtime_seconds = _ws_extract_runtime_seconds_from_listitem(li)
        return not _ws_search_available(search_title, year, alt_titles=alt_titles, runtime_seconds=runtime_seconds)
    except Exception:
        return False


def _ws_is_search_result_allowed_by_query(li, params):
    """When user is on a TMDb search page (e.g. Search - The Menu), do not
    keep unrelated TMDb search hits such as 'Off the Menu'.  Allow exact title,
    title + sequel number, and known aliases (Zootropolis -> Zootopia/Mesto zvirat).
    If no query is available, leave list untouched.
    """
    try:
        query = (params or {}).get('query') or (params or {}).get('search') or (params or {}).get('q') or ''
        qn = _ws_norm_text(query)
        if not qn or len(qn) < 3:
            return True
        title = (li.infolabels or {}).get('title') or li.label or ''
        search_title, alt_titles = _ws_listitem_titles(li)
        tn = _ws_norm_text(title)
        if not tn:
            return True
        allowed = set([qn])
        for src_title in _ws_unique_titles(qn, title, search_title, alt_titles):
            sn = _ws_norm_text(src_title)
            if sn:
                allowed.add(sn)
            for a in _ws_aliases_for_title(src_title):
                allowed.add(_ws_norm_text(a))
        # Exact search title, or sequel number e.g. 'zootropolis 2'
        for a in list(allowed):
            if tn == a:
                return True
            if tn.startswith(a + ' '):
                suffix = tn[len(a):].strip()
                if suffix.isdigit():
                    return True
        return False
    except Exception:
        return True




def _ws_search_rank_for_query(li, params):
    """Rank TMDb search results against the user's query.

    6.16.19 smart merge: keep broadly related results but push exact/near-exact
    matches from later TMDb pages to the top.  This fixes searches where the
    real title is on page 2 while weak matches are on page 1.
    """
    try:
        import difflib
        query = (params or {}).get('query') or (params or {}).get('search') or (params or {}).get('q') or ''
        qn = _ws_norm_text(query)
        if not qn or len(qn) < 3:
            return 0
        title = (li.infolabels or {}).get('title') or li.label or ''
        search_title, alt_titles = _ws_listitem_titles(li)
        candidates = []
        for src in _ws_unique_titles(title, search_title, alt_titles):
            sn = _ws_norm_text(src)
            if sn:
                candidates.append(sn)
            for a in _ws_aliases_for_title(src):
                an = _ws_norm_text(a)
                if an:
                    candidates.append(an)
        candidates = list(dict.fromkeys(candidates))
        if not candidates:
            return 0

        q_tokens = [t for t in qn.split() if t not in _WS_STOPWORDS]
        if not q_tokens:
            q_tokens = qn.split()

        best = 0
        for tn in candidates:
            score = int(difflib.SequenceMatcher(None, qn, tn).ratio() * 100)
            if tn == qn:
                score = max(score, 120)
            elif tn.startswith(qn + ' '):
                suffix = tn[len(qn):].strip()
                if suffix.isdigit():
                    score = max(score, 112)  # sequel / numbered exact
                else:
                    score = max(score, 94)
            elif qn in tn:
                score = max(score, 86)
            elif tn in qn:
                score = max(score, 80)
            else:
                # Token containment for messy punctuation / translated variants.
                if q_tokens:
                    hit = sum(1 for t in q_tokens if t in tn.split() or t in tn)
                    ratio = hit / float(len(q_tokens))
                    score = max(score, int(ratio * 72))

            # Exact year match gets a small boost.
            qy = _ws_extract_year_from_listitem(li)
            if qy and qy in (tn or ''):
                score += 4
            best = max(best, score)
        return best
    except Exception:
        return 0


def _ws_smart_sort_search_results(items, params):
    try:
        query = (params or {}).get('query') or (params or {}).get('search') or (params or {}).get('q') or ''
        if not query:
            return items
        ranked = []
        next_pages = []
        others = []
        for idx, li in enumerate(items):
            try:
                if getattr(li, 'next_page', False):
                    next_pages.append(li)
                    continue
                if (li.infolabels or {}).get('mediatype') == 'movie':
                    rank = _ws_search_rank_for_query(li, params)
                    # Drop extreme unrelated garbage, but keep weak similar titles lower.
                    if rank < 35:
                        continue
                    ranked.append((rank, idx, li))
                else:
                    others.append((idx, li))
            except Exception:
                others.append((idx, li))
        ranked.sort(key=lambda x: (-x[0], x[1]))
        result = [li for _, _, li in ranked] + [li for _, li in others]
        # 6.16.21: do not show bogus/empty 'Next page' after smart merge;
        # keep pagination only when no usable result survived, so the user can dig deeper.
        if not result:
            result += next_pages[:1]
        return result
    except Exception:
        return items

def _ws_dedupe_movie_titles(items):
    """Remove exact duplicate TMDb movie titles after filtering; keep first/best item."""
    out, seen = [], set()
    for li in items:
        try:
            mediatype = (li.infolabels or {}).get('mediatype') or ''
            title = (li.infolabels or {}).get('title') or li.label or ''
            key = _ws_norm_text(title) if mediatype == 'movie' else ''
            if key and key in seen:
                continue
            if key:
                seen.add(key)
        except Exception:
            pass
        out.append(li)
    return out

# --- /Webshare FULL filter custom mod ---


class ContainerDirectoryCommon(CommonContainerAPIs):
    default_cacheonly = False
    update_listing = False  # endOfDirectory(updateListing=) set True to replace current path
    plugin_category = ''  # Container.PluginCategory / ListItem.Property(widget)
    container_content = ''  # Container.Content({})
    container_update = ''  # Add path to call Containr.Update({}) at end of directory
    container_refresh = False  # True call Container.Refresh at end of directory
    sort_by_dbid = False
    kodi_db = None
    thumb_override = 0

    def __init__(self, handle, paramstring, **kwargs):
        # plugin:// params configuration
        self.handle = handle  # plugin:// handle
        self.paramstring = paramstring  # plugin://plugin.video.themoviedb.helper?paramstring
        self.params = kwargs  # paramstring dictionary
        self.parent_params = kwargs.copy()  # TODO: CLEANUP

    @cached_property
    def log_timers(self):
        return get_setting('timer_reports')

    @cached_property
    def timer_lists(self):
        return {}

    @cached_property
    def sort_methods(self):
        return []  # List of kwargs dictionaries [{'sortMethod': SORT_METHOD_UNSORTED}]

    @cached_property
    def property_params(self):
        return {}

    @cached_property
    def filters(self):
        return {
            'filter_key': self.params.get('filter_key', None),
            'filter_value': self.params.get('filter_value', None),
            'filter_operator': self.params.get('filter_operator', None),
            'exclude_key': self.params.get('exclude_key', None),
            'exclude_value': self.params.get('exclude_value', None),
            'exclude_operator': self.params.get('exclude_operator', None)
        }

    @cached_property
    def is_widget(self):
        return boolean(self.params.get('widget', False))

    @cached_property
    def is_cacheonly(self):
        return boolean(self.params.get('cacheonly', self.default_cacheonly))

    @cached_property
    def is_localonly(self):
        return boolean(self.params.get('localonly', False))

    @cached_property
    def is_detailed(self):
        if self.params.get('info') == 'details':
            return True
        return boolean(self.params.get('detailed', False))

    @cached_property
    def is_translated(self):
        return boolean(self.params.get('translated', False))

    @cached_property
    def context_additions(self):
        if self.context_additions_make_node:
            return [(get_localized(32496), 'RunScript(plugin.video.themoviedb.helper,make_node)')]
        return []

    @cached_property
    def context_additions_make_node(self):
        return get_setting('contextmenu_make_node') if not self.is_widget else False

    @cached_property
    def is_excluded(self):
        from tmdbhelper.lib.items.filters import is_excluded
        return is_excluded

    @cached_property
    def trakt_playdata(self):
        from tmdbhelper.lib.items.trakt import TraktPlayData
        return TraktPlayData(
            watchedindicators=get_setting('trakt_watchedindicators'),
            pauseplayprogress=get_setting('trakt_watchedindicators'))

    @cached_property
    def pagination(self):
        if not boolean(self.params.get('nextpage', True)):
            return False
        if self.is_widget and not get_setting('widgets_nextpage'):
            return False
        return True

    @cached_property
    def kodi_db_preferred(self):
        if get_setting('use_kodi_local_db', 'int') == 2:
            return True  # Overwrite TMDb data with Kodi DB data
        return False  # Compliment missing TMDb data with Kodi Db data

    def get_kodi_database(self, tmdb_type):
        if get_setting('use_kodi_local_db', 'int') == 0:
            return
        with TimerList(self.timer_lists, 'get_kodi', log_threshold=0.001, logging=self.log_timers):
            from tmdbhelper.lib.items.kodi import KodiDb
            return KodiDb(tmdb_type)

    @cached_property
    def format_unaired_labels(self):
        return self.parent_params.get('info') not in NO_UNAIRED_LABEL

    @cached_property
    def hide_unaired(self):
        return boolean(self.parent_params.get('hide_unaired'))

    @cached_property
    def only_unaired(self):
        return boolean(self.parent_params.get('only_unaired'))

    def make_item(self, li):
        if not li:
            return

        def finalise_next_page():
            li.params['cacheonly'] = self.is_cacheonly
            li.params['plugin_category'] = self.plugin_category  # Carry the plugin category to next page in plugin:// path
            return li.finalise()

        def finalise_mediaitem():
            # Check if unaired and either apply special formatting or hide item depending on user settings
            li.format_unaired_labels = bool(self.format_unaired_labels and not li.infoproperties.get('specialseason'))
            if li.format_unaired_labels and self.hide_unaired and li.is_unaired:
                return
            if li.format_unaired_labels and self.only_unaired and not li.is_unaired:
                return

            # Add details from Kodi library
            try:
                li.set_details(details=self.kodi_db.get_kodi_details(li), reverse=self.kodi_db_preferred)
            except AttributeError:
                pass

            # Filter out items that are excluded (done after adding Kodi details so can filter against them)
            if self.is_excluded(li, is_listitem=True, **self.filters):
                return

            li.context_additions = self.context_additions
            li.thumb_override = self.thumb_override
            li.infoproperties_additions['widget'] = self.plugin_category
            li.infoproperties_additions.update(self.property_params)

            return li.finalise()

        return finalise_next_page() if li.next_page else finalise_mediaitem()

    def make_items(self, items):
        make_items = [self.make_item(i) for i in items if i]
        make_items = self.sort_items_by_dbid(make_items) if self.sort_by_dbid else make_items
        return make_items

    def sort_items_by_dbid(self, items):
        items_dbid = [li for li in items if li and li.infolabels.get('dbid')]
        items_tmdb = [li for li in items if li and not li.infolabels.get('dbid')]
        return items_dbid + items_tmdb

    @staticmethod
    def build_detailed_items(items):
        return items

    def build_items(self, items):
        """ Build items in threads """

        items = self.build_detailed_items(items)

        # Finalise listitems in parallel threads
        with TimerList(self.timer_lists, '--make', log_threshold=0.001, logging=self.log_timers):
            items = self.make_items(items)

        return items

    def add_items(self, items):
        # Webshare FULL filter (6.16.5 real strict)
        # Setting is ON by default, but can be toggled in Settings > Players.
        # Fail-safe is handled inside _ws_search_available(): on token/API error it shows all items.
        try:
            if get_setting('webshare_filter_available'):
                items = [li for li in items if li and not _ws_should_hide_listitem(li)]
                items = [li for li in items if li and _ws_is_search_result_allowed_by_query(li, getattr(self, 'params', {}))]
                items = _ws_dedupe_movie_titles(items)
                items = _ws_smart_sort_search_results(items, getattr(self, 'params', {}))
                items = [_ws_apply_movie_badge(li) for li in items]
        except Exception:
            pass

        with TimerList(self.timer_lists, '--list', log_threshold=0.001, logging=self.log_timers):
            items = [(li.url, li.get_listitem(), li.is_folder) for li in items if li]
        with TimerList(self.timer_lists, '--dirs', log_threshold=0.001, logging=self.log_timers):
            from xbmcplugin import addDirectoryItems
            addDirectoryItems(self.handle, items)

    def set_mixed_content(self, response):
        lengths = [
            len(response.get('movies', [])),
            len(response.get('shows', [])),
            len(response.get('persons', [])),
            len(response.get('seasons', [])),
            len(response.get('episodes', []))
        ]

        if lengths.index(max(lengths)) == 0:
            self.container_content = 'movies'
        elif lengths.index(max(lengths)) == 1:
            self.container_content = 'tvshows'
        elif lengths.index(max(lengths)) == 2:
            self.container_content = 'actors'
        elif lengths.index(max(lengths)) == 3:
            self.container_content = 'seasons'
        elif lengths.index(max(lengths)) == 4:
            self.container_content = 'episodes'

        if lengths[0] and (lengths[1] or lengths[3] or lengths[4]):
            self.kodi_db = self.get_kodi_database('both')
        elif lengths[0]:
            self.kodi_db = self.get_kodi_database('movie')
        elif (lengths[1] or lengths[3] or lengths[4]):
            self.kodi_db = self.get_kodi_database('tv')

    def set_params_to_container(self):
        params = {f'param.{k}': f'{v}' for k, v in self.params.items() if k and v}
        if self.handle == -1:
            return params
        from xbmcplugin import setProperty
        for k, v in params.items():
            setProperty(self.handle, k, v)  # Set params to container properties
        return params

    def finish_container(self):
        from xbmcplugin import setPluginCategory, setContent, endOfDirectory, addSortMethod
        setPluginCategory(self.handle, self.plugin_category)  # Container.PluginCategory
        setContent(self.handle, self.container_content)  # Container.Content
        for i in self.sort_methods:
            addSortMethod(self.handle, **i)
        endOfDirectory(self.handle, updateListing=self.update_listing)

    def get_collection_tmdb_id(self, tmdb_id=None, **kwargs):
        try:
            from tmdbhelper.lib.items.database.baseitem_factories.factory import BaseItemFactory
            sync = BaseItemFactory('movie')
            sync.tmdb_id = tmdb_id or self.query_database.get_tmdb_id(**kwargs)
            return sync.data['infoproperties']['set.tmdb_id']
        except (KeyError, TypeError, AttributeError):
            pass

    def get_tmdb_id(self):
        if self.params.get('info') == 'collection' and self.params.get('tmdb_type') == 'movie':
            self.params['tmdb_type'] = 'collection'
            self.params['tmdb_id'] = self.get_collection_tmdb_id(**self.params)
            return

        if self.params.get('tmdb_id'):
            return

        self.params['tmdb_id'] = self.query_database.get_tmdb_id(**self.params)

    def get_items(self, **kwargs):
        """ Abstract method for getting items
        """
        return

    def get_directory_items(self):
        with TimerList(self.timer_lists, 'get_list', logging=self.log_timers):
            return self.get_items(**self.params)

    def get_directory(self, items_only=False, build_items=True):

        with TimerList(self.timer_lists, 'total', logging=self.log_timers):
            self.trakt_playdata.pre_sync_start(**self.params)

            items = self.get_directory_items()

            if not items:
                return

            if not build_items:
                return items

            self.property_params.update(self.set_params_to_container())
            self.plugin_category = self.params.get('plugin_category') or self.plugin_category

            with TimerList(self.timer_lists, '--sync', log_threshold=0.001, logging=self.log_timers):
                self.trakt_playdata.pre_sync_join()

            with TimerList(self.timer_lists, 'add_items', logging=self.log_timers):
                items = self.build_items(items)
                if items_only:
                    return items
                self.add_items(items)
            self.finish_container()

        if self.log_timers:
            from tmdbhelper.lib.files.futils import write_to_file
            from tmdbhelper.lib.addon.logger import log_timer_report
            from tmdbhelper.lib.addon.tmdate import get_todays_date
            report_data = log_timer_report(self.timer_lists, self.paramstring, logging=False)
            write_to_file(''.join(report_data), 'timer_report', f'{get_todays_date()}.txt', join_addon_data=True, append_to_file=True)

        if self.container_update:
            executebuiltin(f'Container.Update({self.container_update})')

        if self.container_refresh:
            executebuiltin('Container.Refresh')


class ContainerDirectory(ContainerDirectoryCommon):

    @cached_property
    def lidc_cache_refresh(self):
        if self.is_cacheonly:
            return 'never'
        if self.is_detailed:
            return None
        return 'basic'

    @cached_property
    def lidc(self):
        from tmdbhelper.lib.items.database.listitem import ListItemDetails
        lidc = ListItemDetails(self)
        lidc.parent_params = self.parent_params
        lidc.pagination = self.pagination
        lidc.cache_refresh = self.lidc_cache_refresh
        lidc.cache_translations = self.is_translated
        lidc.extendedinfo = self.is_detailed
        lidc.timer_lists = self.timer_lists
        lidc.log_timers = self.log_timers
        return lidc

    def build_detailed_item(self, li):
        if li.infoproperties.get('label_override'):
            li.label = f"{li.infoproperties['label_override']}"
        if li.infoproperties.get('label_affix'):
            li.label = f"{li.infoproperties['label_affix']}. {li.label}"
        if li.infoproperties.get('plot_affix'):
            li.infolabels['plot'] = f"{li.infoproperties['plot_affix']}{li.infolabels.get('plot')}"
        return li

    def build_detailed_items(self, items):
        with TimerList(self.timer_lists, '--build', log_threshold=0.001, logging=self.log_timers):
            items = self.lidc.configure_listitems_threaded(items)
            return [i for i in (self.build_detailed_item(li) for li in items if li) if i]


class ContainerDefaultCacheDirectory(ContainerDirectory):
    default_cacheonly = False


class ContainerCacheOnlyDirectory(ContainerDirectory):
    default_cacheonly = True
