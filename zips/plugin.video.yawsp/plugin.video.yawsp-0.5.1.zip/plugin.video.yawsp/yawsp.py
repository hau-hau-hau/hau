# -*- coding: utf-8 -*-
# Module: default
# Author: cache-sk
# Created on: 10.5.2020
# License: AGPL v.3 https://www.gnu.org/licenses/agpl-3.0.html

import io
import os
import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import requests.cookies
from xml.etree import ElementTree as ET
import hashlib
from md5crypt import md5crypt
import traceback
import json
import unidecode
import re
import zipfile
import uuid
import series_manager

try:
    from urllib import urlencode
    from urlparse import parse_qsl, urlparse
except ImportError:
    from urllib.parse import urlencode
    from urllib.parse import parse_qsl, urlparse

try:
    from xbmc import translatePath
except ImportError:
    from xbmcvfs import translatePath

BASE = 'https://webshare.cz'
API = BASE + '/api/'
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36"
HEADERS = {'User-Agent': UA, 'Referer':BASE}
REALM = ':Webshare:'
CATEGORIES = ['','video','images','audio','archives','docs','adult']
SORTS = ['','recent','rating','largest','smallest']
SEARCH_HISTORY = 'search_history'
NONE_WHAT = '%#NONE#%'
BACKUP_DB = 'D1iIcURxlR'

_url = sys.argv[0]
_handle = int(sys.argv[1])
_addon = xbmcaddon.Addon()
_session = requests.Session()
_session.headers.update(HEADERS)
_profile = translatePath( _addon.getAddonInfo('profile'))
try:
    _profile = _profile.decode("utf-8")
except:
    pass

def get_url(**kwargs):
    return '{0}?{1}'.format(_url, urlencode(kwargs, 'utf-8'))

def api(fnct, data):
    response = _session.post(API + fnct + "/", data=data)
    return response

def is_ok(xml):
    status = xml.find('status').text
    return status == 'OK'

def popinfo(message, heading=_addon.getAddonInfo('name'), icon=xbmcgui.NOTIFICATION_INFO, time=3000, sound=False): #NOTIFICATION_WARNING NOTIFICATION_ERROR
    xbmcgui.Dialog().notification(heading, message, icon, time, sound=sound)

def login():
    username = _addon.getSetting('wsuser')
    password = _addon.getSetting('wspass')
    if username == '' or password == '':
        popinfo(_addon.getLocalizedString(30101), sound=True)
        _addon.openSettings()
        return
    response = api('salt', {'username_or_email': username})
    xml = ET.fromstring(response.content)
    if is_ok(xml):
        salt = xml.find('salt').text
        try:
            encrypted_pass = hashlib.sha1(md5crypt(password.encode('utf-8'), salt.encode('utf-8'))).hexdigest()
            pass_digest = hashlib.md5(username.encode('utf-8') + REALM + encrypted_pass.encode('utf-8')).hexdigest()
        except TypeError:
            encrypted_pass = hashlib.sha1(md5crypt(password.encode('utf-8'), salt.encode('utf-8')).encode('utf-8')).hexdigest()
            pass_digest = hashlib.md5(username.encode('utf-8') + REALM.encode('utf-8') + encrypted_pass.encode('utf-8')).hexdigest()
        response = api('login', {'username_or_email': username, 'password': encrypted_pass, 'digest': pass_digest, 'keep_logged_in': 1})
        xml = ET.fromstring(response.content)
        if is_ok(xml):
            token = xml.find('token').text
            _addon.setSetting('token', token)
            return token
        else:
            popinfo(_addon.getLocalizedString(30102), icon=xbmcgui.NOTIFICATION_ERROR, sound=True)
            _addon.openSettings()
    else:
        popinfo(_addon.getLocalizedString(30102), icon=xbmcgui.NOTIFICATION_ERROR, sound=True)
        _addon.openSettings()

def revalidate():
    token = _addon.getSetting('token')
    if len(token) == 0:
        if login():
            return revalidate()
    else:
        response = api('user_data', { 'wst': token })
        xml = ET.fromstring(response.content)
        status = xml.find('status').text
        if is_ok(xml):
            vip = xml.find('vip').text
            if vip != '1':
                popinfo(_addon.getLocalizedString(30103), icon=xbmcgui.NOTIFICATION_WARNING)
            return token
        else:
            if login():
                return revalidate()

def todict(xml, skip=[]):
    result = {}
    for e in xml:
        if e.tag not in skip:
            value = e.text if len(list(e)) == 0 else todict(e,skip)
            if e.tag in result:
                if isinstance(result[e.tag], list):
                    result[e.tag].append(value)
                else:
                    result[e.tag] = [result[e.tag],value]
            else:
                result[e.tag] = value
    #result = {e.tag:(e.text if len(list(e)) == 0 else todict(e,skip)) for e in xml if e.tag not in skip}
    return result
            
def sizelize(txtsize, units=['B','KB','MB','GB']):
    if txtsize:
        size = float(txtsize)
        if size < 1024:
            size = str(size) + units[0]
        else:
            size = size / 1024
            if size < 1024:
                size = str(int(round(size))) + units[1]
            else:
                size = size / 1024
                if size < 1024:
                    size = str(round(size,2)) + units[2]
                else:
                    size = size / 1024
                    size = str(round(size,2)) + units[3]
        return size
    return str(txtsize)
    
def labelize(file):
    if '_display_label' in file:
        return file['_display_label']
    if 'size' in file:
        size = sizelize(file['size'])
    elif 'sizelized' in file:
        size = file['sizelized']
    else:
        size = '?'
    label = file['name'] + ' (' + size + ')'
    return label
    
def tolistitem(file, addcommands=[]):
    label = labelize(file)
    listitem = xbmcgui.ListItem(label=label)
    if '_display_label2' in file and file['_display_label2']:
        try:
            listitem.setLabel2(file['_display_label2'])
        except Exception:
            pass
    if 'img' in file:
        listitem.setArt({'thumb': file['img']})
    # Expose clean labels/details to TMDb Helper JSON-RPC directory reader
    info_title = file.get('_tmdb_title', label) if isinstance(file, dict) else label
    info_plot = file.get('_display_label2', '') if isinstance(file, dict) else ''
    try:
        listitem.setInfo('video', {'title': info_title, 'plot': info_plot, 'plotoutline': info_plot})
    except Exception:
        listitem.setInfo('video', {'title': label})
    listitem.setProperty('IsPlayable', 'true')
    commands = []
    commands.append(( _addon.getLocalizedString(30211), 'RunPlugin(' + get_url(action='info',ident=file['ident']) + ')'))
    commands.append(( _addon.getLocalizedString(30212), 'RunPlugin(' + get_url(action='download',ident=file['ident']) + ')'))
    if addcommands:
        commands = commands + addcommands
    listitem.addContextMenuItems(commands)
    return listitem

def ask(what):
    if what is None:
        what = ''
    kb = xbmc.Keyboard(what, _addon.getLocalizedString(30007))
    kb.doModal() # Onscreen keyboard appears
    if kb.isConfirmed():
        return kb.getText() # User input
    return None
    
def loadsearch():
    history = []
    try:
        if not os.path.exists(_profile):
            os.makedirs(_profile)
    except Exception as e:
        traceback.print_exc()
    
    try:
        with io.open(os.path.join(_profile, SEARCH_HISTORY), 'r', encoding='utf8') as file:
            fdata = file.read()
            file.close()
            try:
                history = json.loads(fdata, "utf-8")
            except TypeError:
                history = json.loads(fdata)
    except Exception as e:
        traceback.print_exc()

    return history
    
def storesearch(what):
    if what:
        size = int(_addon.getSetting('shistory'))

        history = loadsearch()

        if what in history:
            history.remove(what)

        history = [what] + history
        
        if len(history)>size:
            history = history[:size]

        try:
            with io.open(os.path.join(_profile, SEARCH_HISTORY), 'w', encoding='utf8') as file:
                try:
                    data = json.dumps(history).decode('utf8')
                except AttributeError:
                    data = json.dumps(history)
                file.write(data)
                file.close()
        except Exception as e:
            traceback.print_exc()

def removesearch(what):
    if what:
        history = loadsearch()
        if what in history:
            history.remove(what)
            try:
                with io.open(os.path.join(_profile, SEARCH_HISTORY), 'w', encoding='utf8') as file:
                    try:
                        data = json.dumps(history).decode('utf8')
                    except AttributeError:
                        data = json.dumps(history)
                    file.write(data)
                    file.close()
            except Exception as e:
                traceback.print_exc()

def _norm_for_match(value):
    if value is None:
        return ''
    try:
        value = unidecode.unidecode(value)
    except Exception:
        pass
    value = value.lower()
    return re.sub(r'[^a-z0-9]+', '', value)

def _contains_blocked_video_word(name):
    if not name:
        return False
    n = name.lower()
    n = n.replace('_', ' ').replace('.', ' ').replace('-', ' ')
    blocked = [
        'trailer', 'teaser', 'sample', 'preview', 'featurette',
        'behind the scenes', 'behind scenes', 'making of', 'ukazka',
        'ukážka', 'trailer cz', 'trailer sk'
    ]
    for word in blocked:
        if word in n:
            return True
    return False


def _compact_words(value):
    """Normalize a title into words for matching filenames."""
    if value is None:
        return []
    try:
        value = unidecode.unidecode(value)
    except Exception:
        pass
    value = value.lower()
    return [w for w in re.split(r'[^a-z0-9]+', value) if w]


# Smart fallback aliases for TMDb searches.
# Used only in strict=1 mode so normal YAWsP searching stays unchanged.
_TITLE_ALIASES = {
    'zootropolis': [
        'Zootropolis', 'Zo Tropolis', 'Zotropolis', 'Zootopia',
        'Mesto zvirat', 'Mesto zvířat', 'Město zvířat', 'Mesto zvierat'
    ],
    'zootopia': [
        'Zootopia', 'Zootropolis', 'Zo Tropolis', 'Zotropolis',
        'Mesto zvirat', 'Mesto zvířat', 'Město zvířat', 'Mesto zvierat'
    ],
    'parazit': ['Parasite', 'Gisaengchung', '기생충'],
    'parasite': ['Parasite', 'Parazit', 'Gisaengchung', '기생충'],
    'gisaengchung': ['Parasite', 'Parazit', '기생충'],
    '기생충': ['Parasite', 'Parazit', 'Gisaengchung'],
}

def _alias_key(value):
    try:
        value = unidecode.unidecode(value or '')
    except Exception:
        value = value or ''
    return re.sub(r'[^a-z0-9]+', '', value.lower())

def _dedupe_keep_order(values):
    out, seen = [], set()
    for v in values:
        v = (v or '').strip()
        if not v:
            continue
        key = v.lower()
        if key in seen:
            continue
        seen.add(key)
        out.append(v)
    return out

def _title_aliases(value):
    aliases = [value or '']
    try:
        ascii_value = unidecode.unidecode(value or '')
        aliases.append(ascii_value)
    except Exception:
        pass
    key = _alias_key(value)
    if key in _TITLE_ALIASES:
        aliases.extend(_TITLE_ALIASES[key])
    # Also try alias if the value contains a known alias key as part of a longer search.
    for alias_key, alias_values in _TITLE_ALIASES.items():
        if alias_key and alias_key in key:
            aliases.extend(alias_values)
    return _dedupe_keep_order(aliases)



def _param_title_values(params, fallback=''):
    """All title variants sent by TMDb Helper, in priority order.

    0.5.4: TMDb may send native-script originaltitle (e.g. 기생충), while
    Webshare uploads use international/localized Latin names. Include title,
    localtitle and originaltitle as aliases, but keep duplicates out.
    """
    values = []
    for key in ('title', 'localtitle', 'originaltitle', 'alttitle'):
        v = params.get(key, '') if params else ''
        if v:
            values.append(v.replace('+', ' '))
    if fallback:
        values.append(str(fallback).replace('+', ' '))
    out, seen = [], set()
    for v in values:
        for a in _title_aliases(v):
            k = _alias_key(a)
            if k and k not in seen:
                seen.add(k); out.append(a)
    return out

def _extract_years(value):
    if not value:
        return []
    return re.findall(r'\b(?:19|20)\d{2}\b', value)

def _release_words_for_no_year(value):
    """Words left after removing common release metadata.
    Used when the filename/upload has no year: allow exact title uploads like
    Smile.1080p.CZ, but avoid Smile.2 when the requested movie is Smile.
    """
    words = _compact_words(value)
    drop = set([
        '2160p','1080p','720p','480p','4k','uhd','hdr','dv','dolby','vision',
        'h264','h265','x264','x265','hevc','avc','aac','ac3','eac3','dts',
        'web','webdl','web-dl','webrip','bluray','blu','ray','brrip','hdrip',
        'remux','rip','cz','sk','cs','en','eng','dabing','dabbed','sub','subs',
        'titulky','tit','dual','multi','proper','repack','extended','uncut',
        'internal','complete','film','movie','movies','serial','serialy'
    ])
    cleaned = []
    for w in words:
        if w in drop:
            continue
        if re.match(r'^(19|20)\d{2}$', w):
            continue
        if re.match(r'^s\d{1,2}e\d{1,2}$', w):
            continue
        if re.match(r'^\d{1,2}x\d{1,2}$', w):
            continue
        cleaned.append(w)
    return cleaned

def _no_year_title_match(title, result_name):
    """Hybrid strict rule for stream list: if upload has no year, keep it only
    when its remaining release-name words are a strong title match.
    This keeps Smile.1080p.CZ but rejects Smile.2.1080p for Smile.
    """
    title_words = _compact_words(title)
    if not title_words:
        return False
    name_words = _release_words_for_no_year(result_name)
    if not name_words:
        return False
    # Exact prefix title, with no conflicting sequel number after it.
    if name_words[:len(title_words)] == title_words:
        extra = name_words[len(title_words):]
        title_nums = set([w for w in title_words if w.isdigit()])
        for w in extra[:2]:
            if w.isdigit() and w not in title_nums:
                return False
        return True
    # Compact exact inclusion for dotted/merged names, e.g. zootropolis/zotropolis aliases.
    compact_title = ''.join(title_words)
    compact_name = ''.join(name_words[:max(len(title_words)+2, 3)])
    return compact_title and compact_title in compact_name

def _make_tmdb_search_variants(what, params):
    """Return multiple Webshare queries for TMDb strict search.
    Example: Zootropolis 2016 -> also tries Zootopia / Mesto zvirat variants.
    """
    strict_enabled = params.get('strict', '0') in ['1', 'true', 'True', 'yes', 'on']
    if not strict_enabled:
        return [what]

    title = params.get('title', '') or what or ''
    title_values = _param_title_values(params, title)
    year = params.get('year', '') or ''
    season = params.get('season', '') or ''
    episode = params.get('episode', '') or ''

    variants = []
    if title and season and episode:
        try:
            s = int(season); e = int(episode)
            for alias in title_values:
                variants.append('%s S%02dE%02d' % (alias, s, e))
                variants.append('%s %dx%02d' % (alias, s, e))
        except Exception:
            for alias in title_values:
                variants.append('%s S%sE%s' % (alias, season, episode))
                variants.append('%s %sx%s' % (alias, season, episode))
    elif title:
        for alias in title_values:
            if year:
                variants.append('%s %s' % (alias, year))
            variants.append(alias)

    variants.append(what)
    return _dedupe_keep_order(variants)

def _make_tmdb_search_what(params, what):
    """Build a Webshare query from TMDb Helper params.
    TMDb Helper sometimes does not support formatted placeholders like {season:02}.
    This function pads season/episode inside YAWsP instead.
    """
    strict_enabled = params.get('strict', '0') in ['1', 'true', 'True', 'yes', 'on']
    if not strict_enabled:
        return what

    title = params.get('title', '') or ''
    year = params.get('year', '') or ''
    season = params.get('season', '') or ''
    episode = params.get('episode', '') or ''

    # Episode query: "Euphoria S01E01" (matches common Webshare naming)
    if title and season and episode:
        try:
            s = int(season)
            e = int(episode)
            return '%s S%02dE%02d' % (title, s, e)
        except Exception:
            return '%s S%sE%s' % (title, season, episode)

    # Movie query: "The Menu 2022"
    if title and year:
        return '%s %s' % (title, year)

    if title:
        return title
    return what


def _quality_score(name):
    n = (name or '').lower()
    score = 0
    if 'remux' in n:
        score += 800
    if '2160p' in n or '4k' in n or 'uhd' in n or '3840' in n:
        score += 700
    elif '1080p' in n or 'fullhd' in n or 'fhd' in n:
        score += 500
    elif '720p' in n or 'hd' in n:
        score += 300
    if 'hdr' in n or 'dolby vision' in n or ' dv ' in (' ' + n + ' '):
        score += 80
    if 'hevc' in n or 'x265' in n or 'h265' in n:
        score += 60
    if 'web-dl' in n or 'webrip' in n or 'bluray' in n or 'blu-ray' in n:
        score += 40
    if 'cam' in n or 'telesync' in n or 'ts' in n:
        score -= 300
    return score



def _resolution_rank(res):
    r = (res or '').lower()
    if '2160' in r or '4k' in r or 'uhd' in r:
        return 300
    if '1080' in r:
        return 200
    if '720' in r:
        return 100
    return 0

def _bitrate_rank(value):
    if not value:
        return 0
    try:
        v = str(value).lower().replace(',', '.').strip()
        m = re.search(r'(\d+(?:\.\d+)?)', v)
        if not m:
            return 0
        n = float(m.group(1))
        if 'gbps' in v:
            n *= 1000
        elif 'kbps' in v:
            n /= 1000
        elif 'bps' in v and 'mbps' not in v:
            n /= 1000000
        return int(min(n, 80))
    except Exception:
        return 0

def _preferred_stream_sort_score(item):
    """Sort results by language first, then quality.
    Preference:
      1) CZ/SK audio (dabing)
      2) CZ/SK subtitles
      3) EN audio
      4) resolution / bitrate / technical quality
    """
    audio = item.get('_sort_audio_langs') or []
    subs = item.get('_sort_sub_langs') or []
    res = item.get('_sort_resolution') or ''
    bitrate = item.get('_sort_bitrate') or ''
    name = item.get('name', '')
    score = 0

    # Language priority: dabing > titulky > EN.
    if 'CZ' in audio or 'SK' in audio:
        score += 10000
        # Prefer SK/CZ order a bit over mixed/unknown.
        if 'SK' in audio:
            score += 120
        if 'CZ' in audio:
            score += 100
    elif 'CZ' in subs or 'SK' in subs:
        score += 8000
        if 'SK' in subs:
            score += 120
        if 'CZ' in subs:
            score += 100
    elif 'EN' in audio:
        score += 6000

    # Then quality and bitrate.
    score += _resolution_rank(res)
    score += _bitrate_rank(bitrate)
    score += _quality_score(name) // 10
    return score

def _strict_match(item, what, params):
    name = item.get('name', '') if isinstance(item, dict) else ''
    if _contains_blocked_video_word(name):
        return False

    if params.get('strict', '0') not in ['1', 'true', 'True', 'yes', 'on']:
        return True

    title = params.get('title', None) or what or ''
    title_values = _param_title_values(params, title)
    clean_name = _norm_for_match(name)

    # Remove obvious episode/year/quality fragments from title before title matching.
    title_for_match = re.sub(r'\b(19|20)\d{2}\b', ' ', title)
    title_for_match = re.sub(r'\bS\d{1,2}E\d{1,2}\b', ' ', title_for_match, flags=re.I)
    title_for_match = re.sub(r'\b\d{1,2}x\d{1,2}\b', ' ', title_for_match, flags=re.I)
    title_for_match = re.sub(r'\b(2160p|1080p|720p|4k|uhd|hdr|hevc|x265|x264|web-dl|webrip|bluray|remux)\b', ' ', title_for_match, flags=re.I)

    alias_word_sets = []
    for tv in title_values:
        tv_match = re.sub(r'\b(19|20)\d{2}\b', ' ', tv)
        tv_match = re.sub(r'\bS\d{1,2}E\d{1,2}\b', ' ', tv_match, flags=re.I)
        tv_match = re.sub(r'\b\d{1,2}x\d{1,2}\b', ' ', tv_match, flags=re.I)
        for alias in _title_aliases(tv_match):
            words = _compact_words(alias)
            if words:
                alias_word_sets.append(words)

    # Require either the normal title words OR one known alias (e.g. Zootropolis -> Zootopia / Mesto zvirat).
    if alias_word_sets and not any(all(word in clean_name for word in words) for words in alias_word_sets):
        return False

    year = params.get('year', '')
    season = params.get('season', '')
    episode = params.get('episode', '')

    if year and year.isdigit() and not (season and episode):
        result_years = _extract_years(name)
        # 0.5.7: movie streams must contain the requested release year in the filename.
        # This removes no-year false positives like Smile.1080p.CZ when TMDb expects Smile 2022.
        if not result_years:
            return False
        if year not in result_years:
            return False
    elif year and year.isdigit():
        result_years = _extract_years(name)
        if result_years and year not in result_years:
            return False

    episode = params.get('episode', '')
    if season and episode:
        try:
            s = int(season)
            e = int(episode)
            patterns = [
                r'\bS%02dE%02d\b' % (s, e),
                r'\bS%dE%d\b' % (s, e),
                r'\b%dx%02d\b' % (s, e),
                r'\b%d\s*x\s*%02d\b' % (s, e),
                r'\b%02d%02d\b' % (s, e)
            ]
            if not any(re.search(p, name, re.IGNORECASE) for p in patterns):
                return False
        except Exception:
            pass

    return True


def _detect_resolution(name, info=None):
    text = (name or '').lower()
    if info:
        try:
            text += ' ' + json.dumps(info).lower()
        except Exception:
            pass
    if '2160p' in text or '4k' in text or 'uhd' in text or '3840' in text:
        return '4K'
    if '1080p' in text or 'fullhd' in text or 'fhd' in text:
        return '1080p'
    if '720p' in text:
        return '720p'
    # Try width/height from API info
    try:
        width = str(info.get('width', '') if info else '')
        height = str(info.get('height', '') if info else '')
        if width and int(width) >= 3800:
            return '4K'
        if height and int(height) >= 2000:
            return '4K'
        if height and int(height) >= 1000:
            return '1080p'
        if height and int(height) >= 700:
            return '720p'
    except Exception:
        pass
    return '?'

def _uniq_keep_order(values):
    out = []
    for v in values:
        if v and v not in out:
            out.append(v)
    return out

def _map_language_token(value):
    """Normalize language tokens from filename/API/MediaInfo.

    Supports common ISO codes and human names used by Webshare uploaders:
    Czech: CZ/CZE/CES/CS/Czech/Cesky/Čeština
    Slovak: SK/SVK/SLK/Slovak/Slovensky/Slovenčina
    plus common other audio languages so labels can show EN/ES/etc.
    """
    if value is None:
        return None
    v = str(value).strip().lower()
    if not v:
        return None
    v = re.sub(r'[^a-z0-9á-ž]+', ' ', v, flags=re.I).strip()
    aliases = [x for x in re.split(r'[/,;| ]+', v) if x] + [v]
    for token in aliases:
        if re.search(r'^(cz|cs|cze|ces|czech|czechia|cesky|česky|ceske|české|čeština|cestina|cestina|ceshtina)$', token, flags=re.I):
            return 'CZ'
        if re.search(r'^(sk|svk|slk|slovak|slovensky|slovenský|slovenske|slovenské|slovenčina|slovencina)$', token, flags=re.I):
            return 'SK'
        if re.search(r'^(en|eng|english|anglicky|anglický|anglictina|angličtina)$', token, flags=re.I):
            return 'EN'
        if re.search(r'^(es|esp|spa|spanish|espanol|español|spanelsky|španělsky|spanielsky|španielsky)$', token, flags=re.I):
            return 'ES'
        if re.search(r'^(de|ger|deu|german|nemecky|německy|nemcina|němčina)$', token, flags=re.I):
            return 'DE'
        if re.search(r'^(fr|fre|fra|french|francuzsky|francouzsky|francúzsky)$', token, flags=re.I):
            return 'FR'
        if re.search(r'^(it|ita|italian|italsky|taliansky)$', token, flags=re.I):
            return 'IT'
        if re.search(r'^(pl|pol|polish|polsky|poľsky)$', token, flags=re.I):
            return 'PL'
        if re.search(r'^(hu|hun|hungarian|madarsky|maďarsky)$', token, flags=re.I):
            return 'HU'
        if re.search(r'^(ru|rus|russian|rusky)$', token, flags=re.I):
            return 'RU'
        if re.search(r'^(jp|jpn|ja|japanese|japonsky)$', token, flags=re.I):
            return 'JP'
        if re.search(r'^(ko|kor|korean|korejsky)$', token, flags=re.I):
            return 'KO'
    return None

def _walk_dicts(obj):
    """Yield every dict inside a nested Webshare/MediaInfo structure."""
    if isinstance(obj, dict):
        yield obj
        for v in obj.values():
            for x in _walk_dicts(v):
                yield x
    elif isinstance(obj, list):
        for v in obj:
            for x in _walk_dicts(v):
                yield x


def _track_kind(track):
    """Best effort MediaInfo track type detector: audio / text / video / general / ''."""
    if not isinstance(track, dict):
        return ''
    vals = []
    for k in ('@type', 'type', 'kind', 'streamtype', 'stream_type', 'track_type', 'codec_type'):
        if k in track and track.get(k) is not None:
            vals.append(str(track.get(k)).lower())
    # Some XML->dict converters store attributes as nested keys.
    for k, v in track.items():
        kl = str(k).lower()
        if kl.endswith('type') and not isinstance(v, (dict, list)):
            vals.append(str(v).lower())
    txt = ' '.join(vals)
    if any(x in txt for x in ('audio', 'sound')):
        return 'audio'
    if any(x in txt for x in ('text', 'subtitle', 'subtitles', 'sub')):
        return 'text'
    if 'video' in txt:
        return 'video'
    if 'general' in txt:
        return 'general'
    return ''


def _lang_from_track(track):
    """Collect languages from keys that usually contain real track language metadata."""
    langs = []
    if not isinstance(track, dict):
        return langs
    for key in ('language', 'lang', 'language_string', 'language_string1', 'languagecode',
                'language_code', 'audio_language', 'subtitle_language', 'title', 'name'):
        if key in track:
            val = track.get(key)
            # MediaInfo can store Language_String as 'Czech / English'
            if isinstance(val, (list, tuple)):
                vals = val
            else:
                vals = re.split(r'[/,;|]+', str(val))
            for v in vals:
                mapped = _map_language_token(v)
                if mapped:
                    langs.append(mapped)
    return _uniq_keep_order(langs)


def _collect_audio_langs_from_info(info):
    """Prefer real audio-track language metadata from Webshare/MediaInfo.

    This avoids showing CZ audio just because filename contains 'CZ tit'.
    """
    langs = []
    if info:
        # 1) Strict MediaInfo-style tracks marked as Audio.
        for d in _walk_dicts(info):
            if _track_kind(d) == 'audio':
                langs.extend(_lang_from_track(d))
        if langs:
            return _uniq_keep_order(langs)

        # 2) Fallback to subtrees explicitly named audio/sound.
        def visit(obj, inside_audio=False):
            if isinstance(obj, dict):
                for k, v in obj.items():
                    kl = str(k).lower()
                    next_audio = inside_audio or kl in ('audio', 'audio_stream', 'audiostream', 'sound', 'sounds')
                    if next_audio and kl in ('language', 'lang', 'language_string', 'title', 'name', 'audio_language', 'audio_lang'):
                        mapped = _map_language_token(v)
                        if mapped:
                            langs.append(mapped)
                    visit(v, next_audio)
            elif isinstance(obj, list):
                for x in obj:
                    visit(x, inside_audio)
        visit(info, False)
    return _uniq_keep_order(langs)


def _collect_subtitle_langs_from_info(info):
    """Collect real subtitle/text track languages as CZ/SK/EN only."""
    langs = []
    if info:
        # 1) Strict MediaInfo-style tracks marked as Text/Subtitle.
        for d in _walk_dicts(info):
            if _track_kind(d) == 'text':
                langs.extend(_lang_from_track(d))
        if langs:
            return _uniq_keep_order(langs)

        # 2) Fallback to subtrees explicitly named subtitle/text.
        def visit(obj, inside_sub=False):
            if isinstance(obj, dict):
                for k, v in obj.items():
                    kl = str(k).lower()
                    next_sub = inside_sub or kl in ('text', 'subtitle', 'subtitles', 'sub', 'subs')
                    if next_sub and kl in ('language', 'lang', 'language_string', 'title', 'name', 'subtitle_language', 'subtitle_lang'):
                        mapped = _map_language_token(v)
                        if mapped:
                            langs.append(mapped)
                    visit(v, next_sub)
            elif isinstance(obj, list):
                for x in obj:
                    visit(x, inside_sub)
        visit(info, False)
    return _uniq_keep_order(langs)


def _detect_subtitle_langs(name, info=None):
    """Detect subtitle languages separately from audio languages."""
    subs = _collect_subtitle_langs_from_info(info)

    text = ' ' + (name or '').lower() + ' '
    text = text.replace('.', ' ').replace('_', ' ').replace('-', ' ')

    # explicit subtitle markers only; do not treat plain CZ/EN in filename as subtitle.
    patterns = {
        'CZ': [r'\b(cz|cs|cze|ces|czech|cesk[yýeé]?|česk[yýeé]?|čeština|cestina)\s*(\+\s*)?(tit|sub|subs|subtitle|subtitles|titulky)\b',
               r'\b(czech|cesk[yýeé]?|česk[yýeé]?|čeština|cestina)\s*(tit|sub|subs|subtitle|subtitles|titulky)\b',
               r'\b(tit|sub|subs|subtitle|subtitles|titulky)\s*(cz|cs|cze|ces|czech|cesk[yýeé]?|česk[yýeé]?|čeština|cestina)\b'],
        'SK': [r'\b(sk|svk|slk|slovak|slovensk[yýeé]?|slovenčina|slovencina)\s*(\+\s*)?(tit|sub|subs|subtitle|subtitles|titulky)\b',
               r'\b(slovak|slovensk[yýeé]?|slovenčina|slovencina|svk|slk)\s*(tit|sub|subs|subtitle|subtitles|titulky)\b',
               r'\b(tit|sub|subs|subtitle|subtitles|titulky)\s*(sk|svk|slk|slovak|slovensk[yýeé]?|slovenčina|slovencina)\b'],
        'EN': [r'\b(en|eng|english)\s*(\+\s*)?(tit|sub|subs|subtitle|subtitles)\b',
               r'\b(tit|sub|subs|subtitle|subtitles)\s*(en|eng|english)\b']
    }
    for lang, pats in patterns.items():
        if any(re.search(p, text, flags=re.I) for p in pats):
            subs.append(lang)
    return _uniq_keep_order(subs)


def _detect_langs(name, info=None):
    """Detect audio/dabing languages.

    Priority: real API/MediaInfo audio tracks -> filename fallback with subtitle tags removed.
    """
    media_langs = _collect_audio_langs_from_info(info)
    if media_langs:
        return _uniq_keep_order(media_langs)

    text = ' ' + (name or '').lower() + ' '
    text = text.replace('.', ' ').replace('_', ' ').replace('-', ' ')

    # Remove explicit subtitle tags so 'CZ tit' is never displayed as CZ dabing.
    cleaned_text = text
    cleaned_text = re.sub(r'\b(cz|cs|cze|ces|czech|cesk[yýeé]?|česk[yýeé]?|čeština|cestina)\s*(\+\s*)?(tit|sub|subs|subtitle|subtitles|titulky)\b', ' ', cleaned_text, flags=re.I)
    cleaned_text = re.sub(r'\b(sk|svk|slk|slovak|slovensk[yýeé]?|slovenčina|slovencina)\s*(\+\s*)?(tit|sub|subs|subtitle|subtitles|titulky)\b', ' ', cleaned_text, flags=re.I)
    cleaned_text = re.sub(r'\b(en|eng|english)\s*(\+\s*)?(tit|sub|subs|subtitle|subtitles)\b', ' ', cleaned_text, flags=re.I)
    cleaned_text = re.sub(r'\b(tit|sub|subs|subtitle|subtitles|titulky)\s*(cz|cs|cze|ces|sk|svk|slk|en|eng|czech|slovak|english|cesk[yýeé]?|slovensk[yýeé]?)\b', ' ', cleaned_text, flags=re.I)

    langs = []
    patterns = {
        'CZ': [r'\b(cz|cs|cze|ces|czech|cesk[yýeé]?|česk[yýeé]?|čeština|cestina)\b'],
        'SK': [r'\b(sk|svk|slk|slo|slovak|slovensk[yýeé]?|slovenčina|slovencina)\b'],
        'EN': [r'\b(en|eng|english|anglick[yý]?|angličtina|anglictina)\b'],
        'ES': [r'\b(es|esp|spa|spanish|espanol|español|spanelsk[yý]?|španělsk[yý]?|španielsk[yý]?)\b'],
        'DE': [r'\b(de|ger|deu|german|nemeck[yý]?|německ[yý]?|nemcina|němčina)\b'],
        'FR': [r'\b(fr|fre|fra|french|francouzsk[yý]?|francúzsk[yý]?|francuzsk[yý]?)\b'],
        'IT': [r'\b(it|ita|italian|italsk[yý]?|taliansk[yý]?)\b'],
        'PL': [r'\b(pl|pol|polish|polsk[yý]?|poľsk[yý]?)\b'],
        'HU': [r'\b(hu|hun|hungarian|madarsk[yý]?|maďarsk[yý]?)\b'],
        'RU': [r'\b(ru|rus|russian|rusk[yý]?)\b'],
        'JP': [r'\b(jp|jpn|ja|japanese|japonsk[yý]?)\b'],
        'KO': [r'\b(ko|kor|korean|korejsk[yý]?)\b']
    }
    for lang, pats in patterns.items():
        if any(re.search(p, cleaned_text, flags=re.I) for p in pats):
            langs.append(lang)
    return _uniq_keep_order(langs)


def _has_subtitles(name, info=None):
    return bool(_detect_subtitle_langs(name, info)) or any(
        x in (' ' + (name or '').lower().replace('.', ' ').replace('_', ' ').replace('-', ' ') + ' ')
        for x in ['+tit', ' tit ', ' titul', ' subtitle', ' subtitles ', ' subs ', ' sub ']
    )

def _detect_source(name):
    n = (name or '').lower()
    if 'remux' in n:
        return 'REMUX'
    if 'web-dl' in n or 'webdl' in n or ' src web' in n or ' web ' in (' ' + n + ' '):
        return 'WEB'
    if 'bluray' in n or 'blu-ray' in n:
        return 'BluRay'
    if 'webrip' in n:
        return 'WEBRip'
    return ''

def _detect_codec(name, info=None):
    text = (name or '').lower()
    try:
        text += ' ' + json.dumps(info).lower() if info else ''
    except Exception:
        pass
    if any(x in text for x in ['hevc', 'h265', 'h.265', 'x265']):
        return 'HEVC'
    if any(x in text for x in ['h264', 'h.264', 'x264']):
        return 'H264'
    return ''

def _detect_hdr(name):
    n = (name or '').lower()
    parts = []
    if 'dovi' in n or 'dolby vision' in n or re.search(r'\bdv\b', n):
        parts.append('DoVi')
    if 'hdr10' in n:
        parts.append('HDR10')
    elif 'hdr' in n:
        parts.append('HDR')
    return '+'.join(parts)

def _format_bitrate(value):
    if not value:
        return ''
    try:
        v = float(value)
        # Webshare bitrate is often in bps.
        if v > 1000000:
            return str(round(v / 1000000.0, 1)).rstrip('0').rstrip('.') + ' Mbps'
        if v > 1000:
            return str(round(v / 1000.0, 1)).rstrip('0').rstrip('.') + ' Kbps'
        return str(round(v, 2)) + ' bps'
    except Exception:
        return str(value)

def _format_size_short(value):
    try:
        return sizelize(value).replace(' ', '')
    except Exception:
        return ''

def _duration_seconds_from_info(info):
    if not info:
        return 0
    for key in ['duration', 'length', 'runtime']:
        val = info.get(key)
        if not val:
            continue
        try:
            txt = str(val).strip()
            if ':' in txt:
                parts = [float(x) for x in txt.split(':')]
                if len(parts) == 3:
                    return int(parts[0] * 3600 + parts[1] * 60 + parts[2])
                if len(parts) == 2:
                    return int(parts[0] * 60 + parts[1])
            sec = float(txt)
            # Sometimes APIs return milliseconds.
            if sec > 100000:
                sec = sec / 1000.0
            return int(sec)
        except Exception:
            pass
    return 0


def _target_runtime_seconds_from_params(params):
    """Runtime passed by TMDb Helper. Accepts seconds, minutes, HH:MM:SS, or ISO-ish strings."""
    try:
        for key in ('runtime', 'duration', 'tmdb_runtime'):
            val = (params or {}).get(key)
            if not val:
                continue
            txt = str(val).strip()
            if not txt or txt.startswith('{'):
                continue
            if ':' in txt:
                parts = [float(x) for x in txt.split(':') if x != '']
                if len(parts) == 3:
                    sec = int(parts[0] * 3600 + parts[1] * 60 + parts[2])
                elif len(parts) == 2:
                    sec = int(parts[0] * 60 + parts[1])
                else:
                    continue
            else:
                num = float(re.sub(r'[^0-9.]', '', txt) or 0)
                # TMDb Helper/Kodi commonly stores duration in seconds; TMDb runtime is minutes.
                if num <= 0:
                    continue
                sec = int(num * 60) if num < 600 else int(num)
                if sec > 100000:
                    sec = int(sec / 1000)
            if sec >= 20 * 60:
                return sec
    except Exception:
        pass
    return 0


def _duration_filter_status(info, params, tolerance_minutes=8):
    """Return ok/noinfo/bad for duration filtering.

    ok     = duration exists and is close enough to TMDb runtime
    noinfo = Webshare file_info has no duration; keep it but sort lower and mark ?time
    bad    = duration is too far away; hide from stream list
    """
    target = _target_runtime_seconds_from_params(params)
    if not target:
        return 'ok'
    got = _duration_seconds_from_info(info)
    if not got:
        return 'noinfo'
    # Ignore tiny clips and extremely different runtimes. Tolerance is max(8 min, 8%).
    tolerance = max(int(tolerance_minutes * 60), int(target * 0.08))
    return 'ok' if abs(int(got) - int(target)) <= tolerance else 'bad'


def _format_seconds_hm(sec):
    try:
        sec = int(sec or 0)
        if sec <= 0:
            return ''
        m = int(round(sec / 60.0))
        h = m // 60
        mm = m % 60
        return f'{h}:{mm:02d}' if h else f'{mm}m'
    except Exception:
        return ''


def _duration_debug_label(info, params):
    # 0.5.7: duration debug disabled; Webshare often does not provide runtime.
    return ''

def _estimate_bitrate_from_size(size_bytes, info):
    try:
        duration = _duration_seconds_from_info(info)
        if not size_bytes or not duration:
            return ''
        mbps = (float(size_bytes) * 8.0) / float(duration) / 1000000.0
        if mbps <= 0:
            return ''
        return str(round(mbps, 1)).rstrip('0').rstrip('.') + ' Mbps'
    except Exception:
        return ''

def _get_streams(info, kind):
    try:
        streams = info.get(kind, {}).get('stream', [])
        if isinstance(streams, dict):
            streams = [streams]
        if not isinstance(streams, list):
            streams = []
        return streams
    except Exception:
        return []

def _make_detail_labels(item, what, params, token):
    """Create clean two-line labels for TMDb/YAWsP results.
    Top: LANGUAGE - RESOLUTION | Title (Year)
    Bottom: bitrate/audio/source/codec/aspect details when available.
    """
    name = item.get('name', '')
    info = None
    try:
        xmlinfo = getinfo(item.get('ident'), token)
        if xmlinfo is not None:
            info = todict(xmlinfo)
    except Exception:
        info = None

    duration_status = _duration_filter_status(info, params)
    item['_duration_status'] = duration_status

    title = params.get('title') or what or ''
    title = title.replace('+', ' ')
    title = re.sub(r'\s+', ' ', title).strip()
    year = params.get('year') or ''
    # If title was URL encoded by TMDb helper with pluses, clean it. Keep user-facing original.
    if not title:
        title = name
    res = _detect_resolution(name, info)

    # Confidence labels:
    # - DAB / TIT  = language came from real Webshare/API media metadata
    # - DAB? / TIT? = language was guessed from the filename fallback
    real_audio_langs = _collect_audio_langs_from_info(info)
    real_sub_langs = _collect_subtitle_langs_from_info(info)
    langs = real_audio_langs or _detect_langs(name, None)
    sub_langs = real_sub_langs or _detect_subtitle_langs(name, None)
    audio_confident = bool(real_audio_langs)
    sub_confident = bool(real_sub_langs)

    # Show audio/dabing and subtitles separately. Subtitle display is intentionally limited
    # to CZ/SK because those are the useful local subtitle tracks for this setup.
    sub_langs_display = [s for s in sub_langs if s in ('CZ', 'SK')]
    audio_text = (('DAB ' if audio_confident else 'DAB? ') + ', '.join(langs)) if langs else ''
    sub_text = (('TIT ' if sub_confident else 'TIT? ') + ', '.join(sub_langs_display)) if sub_langs_display else ''
    lang_parts = [x for x in (audio_text, sub_text) if x]
    lang_text = ' | '.join(lang_parts) if lang_parts else '?'
    if year:
        main = '%s - %s | %s (%s)' % (lang_text, res, title, year)
    else:
        main = '%s - %s | %s' % (lang_text, res, title)

    details = []
    # Prefer Webshare API bitrate, fallback to an estimate from file size + duration when available.
    bitrate = ''
    if info:
        bitrate = _format_bitrate(info.get('bitrate'))
    if not bitrate:
        bitrate = _estimate_bitrate_from_size(item.get('size'), info)
    if bitrate:
        details.append('net: ' + bitrate)

    # Audio and subtitle languages separated; avoids showing CZ as audio when it is only CZ subtitles.
    audio_langs = _uniq_keep_order(langs)
    if audio_langs:
        details.append(('audio: ' if audio_confident else 'audio?: ') + ', '.join(audio_langs))
    if sub_langs:
        details.append(('tit: ' if sub_confident else 'tit?: ') + ', '.join(sub_langs))
    src = _detect_source(name)
    if src:
        details.append('src: ' + src)
    codec = _detect_codec(name, info)
    hdr = _detect_hdr(name)
    codec_bits = []
    if codec:
        codec_bits.append(codec)
    if hdr:
        codec_bits.append(hdr)
    if codec_bits:
        details.append(' '.join(codec_bits))
    # Aspect ratio from API when present.
    aspect = ''
    try:
        w = int(info.get('width')) if info and info.get('width') else 0
        h = int(info.get('height')) if info and info.get('height') else 0
        if w and h:
            ratio = float(w) / float(h)
            if 1.70 < ratio < 1.85:
                aspect = '16:9'
            elif 2.2 < ratio < 2.5:
                aspect = '2.39:1'
    except Exception:
        pass
    if aspect:
        details.append('asp: ' + aspect)

    duration_debug = _duration_debug_label(info, params)
    if duration_debug:
        details.append(duration_debug)

    # Add size when available.
    size = item.get('sizelized') or (_format_size_short(item.get('size')) if item.get('size') else '')
    if size:
        details.append('size: ' + size)

    # Select Item popup usually shows only one line, so keep the key stream info in the main label.
    # Format: 1080p | CZ / EN | 8 Mbps | 2.39GB | H264 HDR
    label_bits = []
    if res and res != '?':
        label_bits.append(res)
    if lang_text and lang_text != '?':
        label_bits.append(lang_text)
    if bitrate:
        label_bits.append(bitrate)
    if duration_debug:
        label_bits.append(duration_debug)
    if size:
        label_bits.append(size)
    codec_label = ' '.join(codec_bits) if codec_bits else ''
    if codec_label:
        label_bits.append(codec_label)
    # Values used only for smart sorting. They do not change playback.
    item['_sort_audio_langs'] = _uniq_keep_order(langs)
    item['_sort_sub_langs'] = _uniq_keep_order(sub_langs)
    item['_sort_resolution'] = res
    item['_sort_bitrate'] = bitrate
    item['_display_label'] = ' | '.join(label_bits)
    item['_display_label2'] = '  '.join(details)
    item['_tmdb_title'] = item['_display_label']
    item['_tmdb_plot'] = item['_display_label2']
    return item

def _strict_empty_item():
    listitem = xbmcgui.ListItem(label='Nič presné nenájdené')
    listitem.setArt({'icon': 'DefaultAddonsSearch.png'})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='search'), listitem, False)

def dosearch(token, what, category, sort, limit, offset, action, params=None):
    if params is None:
        params = {}

    strict_enabled = params.get('strict', '0') in ['1', 'true', 'True', 'yes', 'on']

    if offset > 0: #prev page
        listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30206))
        listitem.setArt({'icon': 'DefaultAddonsSearch.png'})
        xbmcplugin.addDirectoryItem(_handle, get_url(action=action, what=what, category=category, sort=sort, limit=limit, offset=offset - limit if offset > limit else 0), listitem, True)

    items = []
    seen_idents = set()
    search_variants = _make_tmdb_search_variants(what, params) if strict_enabled and offset == 0 else [what]
    ok_any = False
    total = 0

    for search_what in search_variants:
        response = api('search', {'what': '' if search_what == NONE_WHAT else search_what, 'category': category, 'sort': sort, 'limit': limit, 'offset': offset, 'wst': token, 'maybe_removed': 'true'})
        xml = ET.fromstring(response.content)
        if not is_ok(xml):
            continue
        ok_any = True
        try:
            total = max(total, int(xml.findtext('total') or 0))
        except Exception:
            pass
        for file in xml.iter('file'):
            item = todict(file)
            ident = item.get('ident') or item.get('name')
            if ident in seen_idents:
                continue
            if _strict_match(item, search_what, params):
                seen_idents.add(ident)
                items.append(item)

    if ok_any:
        if not items and strict_enabled:
            _strict_empty_item()

        # In TMDb strict mode, enrich first (languages, subs, bitrate), then sort by
        # CZ/SK dabing > CZ/SK titulky > EN > quality/bitrate.
        if strict_enabled:
            enriched = []
            # Remove visual duplicates after media-info enrichment. Webshare sometimes returns
            # several different ids that are effectively the same stream for the user
            # (same clean label: quality/language/bitrate/size/codec). Keep the first one.
            seen_display = set()
            for item in items:
                try:
                    item = _make_detail_labels(item, what, params, token)
                except Exception:
                    traceback.print_exc()
                if item.get('_duration_status') == 'bad':
                    continue
                display_key = (
                    (item.get('_display_label') or '').strip().lower(),
                    str(item.get('size') or item.get('sizelized') or '').strip().lower(),
                )
                if display_key[0] and display_key in seen_display:
                    continue
                if display_key[0]:
                    seen_display.add(display_key)
                enriched.append(item)
            items = enriched
            items.sort(key=_preferred_stream_sort_score, reverse=True)
        else:
            items.sort(key=lambda x: _quality_score(x.get('name', '')), reverse=True)

        for item in items:
            commands = []
            commands.append(( _addon.getLocalizedString(30214), 'Container.Update(' + get_url(action='search',toqueue=item['ident'], what=what, offset=offset) + ')'))
            listitem = tolistitem(item,commands)
            xbmcplugin.addDirectoryItem(_handle, get_url(action='play',ident=item['ident'],name=item['name']), listitem, False)
        
        try:
            total = int(xml.find('total').text)
        except:
            total = 0
            
        if offset + limit < total and not params.get('strict', '0') in ['1', 'true', 'True', 'yes', 'on']: #next page
            listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30207))
            listitem.setArt({'icon': 'DefaultAddonsSearch.png'})
            xbmcplugin.addDirectoryItem(_handle, get_url(action=action, what=what, category=category, sort=sort, limit=limit, offset=offset+limit), listitem, True)
    else:
        popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)


def has_results_action(params):
    """Lightweight availability check endpoint for TMDb custom builds.
    Returns one directory item named WS_AVAILABLE=1 or WS_AVAILABLE=0.
    Normal YAWsP browsing/playback is unchanged.
    """
    try:
        token = revalidate()
        what = params.get('what', '')
        variants = _make_tmdb_search_variants(what, params) if params.get('strict', '0') in ['1', 'true', 'True', 'yes', 'on'] else [what]
        available = False
        for search_what in variants[:6]:
            response = api('search', {'what': search_what, 'category': 'video', 'sort': 'rating', 'limit': 10, 'offset': 0, 'wst': token, 'maybe_removed': 'true'})
            xml = ET.fromstring(response.content)
            if not is_ok(xml):
                continue
            for file in xml.iter('file'):
                item = todict(file)
                if _strict_match(item, search_what, params):
                    info = None
                    try:
                        if item.get('ident'):
                            xmlinfo = getinfo(item.get('ident'), token)
                            if xmlinfo is not None:
                                info = todict(xmlinfo)
                    except Exception:
                        info = None
                    if _duration_filter_status(info, params) != 'bad':
                        available = True
                        break
            if available:
                break
        label = 'WS_AVAILABLE=1' if available else 'WS_AVAILABLE=0'
        xbmcplugin.addDirectoryItem(_handle, get_url(action='search'), xbmcgui.ListItem(label=label), False)
        xbmcplugin.endOfDirectory(_handle)
    except Exception:
        traceback.print_exc()
        xbmcplugin.addDirectoryItem(_handle, get_url(action='search'), xbmcgui.ListItem(label='WS_AVAILABLE=1'), False)
        xbmcplugin.endOfDirectory(_handle)

def search(params):
    xbmcplugin.setPluginCategory(_handle, _addon.getAddonInfo('name') + " \ " + _addon.getLocalizedString(30201))
    token = revalidate()
    
    updateListing=False
    
    if 'remove' in params:
        removesearch(params['remove'])
        updateListing=True
        
    if 'toqueue' in params:
        toqueue(params['toqueue'],token)
        updateListing=True
    
    what = None
    
    if 'what' in params:
        what = params['what']
    
    if 'ask' in params:
        slast = _addon.getSetting('slast')
        if slast != what:
            what = ask(what)
            if what is not None:
                storesearch(what)
            else:
                updateListing=True

    if what is not None:
        what = _make_tmdb_search_what(params, what)
        if 'offset' not in params:
            _addon.setSetting('slast',what)
        else:
            _addon.setSetting('slast',NONE_WHAT)
            updateListing=True
        
        category = params['category'] if 'category' in params else CATEGORIES[int(_addon.getSetting('scategory'))]
        sort = params['sort'] if 'sort' in params else SORTS[int(_addon.getSetting('ssort'))]
        limit = int(params['limit']) if 'limit' in params else int(_addon.getSetting('slimit'))
        offset = int(params['offset']) if 'offset' in params else 0
        dosearch(token, what, category, sort, limit, offset, 'search', params)
    else:
        _addon.setSetting('slast',NONE_WHAT)
        history = loadsearch()
        listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30205))
        listitem.setArt({'icon': 'DefaultAddSource.png'})
        xbmcplugin.addDirectoryItem(_handle, get_url(action='search',ask=1), listitem, True)
        
        #newest
        listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30208))
        listitem.setArt({'icon': 'DefaultAddonsRecentlyUpdated.png'})
        xbmcplugin.addDirectoryItem(_handle, get_url(action='search',what=NONE_WHAT,sort=SORTS[1]), listitem, True)
        
        #biggest
        listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30209))
        listitem.setArt({'icon': 'DefaultHardDisk.png'})
        xbmcplugin.addDirectoryItem(_handle, get_url(action='search',what=NONE_WHAT,sort=SORTS[3]), listitem, True)
        
        for search in history:
            listitem = xbmcgui.ListItem(label=search)
            listitem.setArt({'icon': 'DefaultAddonsSearch.png'})
            commands = []
            commands.append(( _addon.getLocalizedString(30213), 'Container.Update(' + get_url(action='search',remove=search) + ')'))
            listitem.addContextMenuItems(commands)
            xbmcplugin.addDirectoryItem(_handle, get_url(action='search',what=search,ask=1), listitem, True)
    xbmcplugin.endOfDirectory(_handle, updateListing=updateListing)

def queue(params):
    xbmcplugin.setPluginCategory(_handle, _addon.getAddonInfo('name') + " \ " + _addon.getLocalizedString(30202))
    token = revalidate()
    updateListing=False
    
    if 'dequeue' in params:
        response = api('dequeue_file',{'ident':params['dequeue'],'wst':token})
        xml = ET.fromstring(response.content)
        if is_ok(xml):
            popinfo(_addon.getLocalizedString(30106))
        else:
            popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
        updateListing=True
    
    response = api('queue',{'wst':token})
    xml = ET.fromstring(response.content)
    if is_ok(xml):
        for file in xml.iter('file'):
            item = todict(file)
            commands = []
            commands.append(( _addon.getLocalizedString(30215), 'Container.Update(' + get_url(action='queue',dequeue=item['ident']) + ')'))
            listitem = tolistitem(item,commands)
            xbmcplugin.addDirectoryItem(_handle, get_url(action='play',ident=item['ident'],name=item['name']), listitem, False)
    else:
        popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
    xbmcplugin.endOfDirectory(_handle,updateListing=updateListing)

def toqueue(ident,token):
    response = api('queue_file',{'ident':ident,'wst':token})
    xml = ET.fromstring(response.content)
    if is_ok(xml):
        popinfo(_addon.getLocalizedString(30105))
    else:
        popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)

def history(params):
    xbmcplugin.setPluginCategory(_handle, _addon.getAddonInfo('name') + " \ " + _addon.getLocalizedString(30203))
    token = revalidate()
    updateListing=False
    
    if 'remove' in params:
        remove = params['remove']
        updateListing=True
        response = api('history',{'wst':token})
        xml = ET.fromstring(response.content)
        ids = []
        if is_ok(xml):
            for file in xml.iter('file'):
                if remove == file.find('ident').text:
                    ids.append(file.find('download_id').text)
        else:
            popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
        if ids:
            rr = api('clear_history',{'ids[]':ids,'wst':token})
            xml = ET.fromstring(rr.content)
            if is_ok(xml):
                popinfo(_addon.getLocalizedString(30104))
            else:
                popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
    
    if 'toqueue' in params:
        toqueue(params['toqueue'],token)
        updateListing=True
    
    response = api('history',{'wst':token})
    xml = ET.fromstring(response.content)
    files = []
    if is_ok(xml):
        for file in xml.iter('file'):
            item = todict(file, ['ended_at', 'download_id', 'started_at'])
            if item not in files:
                files.append(item)
        for file in files:
            commands = []
            commands.append(( _addon.getLocalizedString(30213), 'Container.Update(' + get_url(action='history',remove=file['ident']) + ')'))
            commands.append(( _addon.getLocalizedString(30214), 'Container.Update(' + get_url(action='history',toqueue=file['ident']) + ')'))
            listitem = tolistitem(file, commands)
            xbmcplugin.addDirectoryItem(_handle, get_url(action='play',ident=file['ident'],name=file['name']), listitem, False)
    else:
        popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
    xbmcplugin.endOfDirectory(_handle,updateListing=updateListing)
    
def settings(params):
    _addon.openSettings()
    xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())

def infonize(data,key,process=str,showkey=True,prefix='',suffix='\n'):
    if key in data:
        return prefix + (key.capitalize() + ': ' if showkey else '') + process(data[key]) + suffix
    return ''

def fpsize(fps):
    x = round(float(fps),3)
    if int(x) == x:
       return str(int(x))
    return str(x)
    
def getinfo(ident,wst):
    response = api('file_info',{'ident':ident,'wst': wst})
    xml = ET.fromstring(response.content)
    ok = is_ok(xml)
    if not ok:
        response = api('file_info',{'ident':ident,'wst': wst, 'maybe_removed':'true'})
        xml = ET.fromstring(response.content)
        ok = is_ok(xml)
    if ok:
        return xml
    else:
        popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
        return None

def info(params):
    token = revalidate()
    xml = getinfo(params['ident'],token)
    
    if xml is not None:
        info = todict(xml)
        text = ''
        text += infonize(info, 'name')
        text += infonize(info, 'size', sizelize)
        text += infonize(info, 'type')
        text += infonize(info, 'width')
        text += infonize(info, 'height')
        text += infonize(info, 'format')
        text += infonize(info, 'fps', fpsize)
        text += infonize(info, 'bitrate', lambda x:sizelize(x,['bps','Kbps','Mbps','Gbps']))
        if 'video' in info and 'stream' in info['video']:
            streams = info['video']['stream']
            if isinstance(streams, dict):
                streams = [streams]
            for stream in streams:
                text += 'Video stream: '
                text += infonize(stream, 'width', showkey=False, suffix='')
                text += infonize(stream, 'height', showkey=False, prefix='x', suffix='')
                text += infonize(stream,'format', showkey=False, prefix=', ', suffix='')
                text += infonize(stream,'fps', fpsize, showkey=False, prefix=', ', suffix='')
                text += '\n'
        if 'audio' in info and 'stream' in info['audio']:
            streams = info['audio']['stream']
            if isinstance(streams, dict):
                streams = [streams]
            for stream in streams:
                text += 'Audio stream: '
                text += infonize(stream, 'format', showkey=False, suffix='')
                text += infonize(stream,'channels', prefix=', ', showkey=False, suffix='')
                text += infonize(stream,'bitrate', lambda x:sizelize(x,['bps','Kbps','Mbps','Gbps']), prefix=', ', showkey=False, suffix='')
                text += '\n'
        text += infonize(info, 'removed', lambda x:'Yes' if x=='1' else 'No')
        xbmcgui.Dialog().textviewer(_addon.getAddonInfo('name'), text)

def getlink(ident,wst,dtype='video_stream'):
    #uuid experiment
    duuid = _addon.getSetting('duuid')
    if not duuid:
        duuid = str(uuid.uuid4())
        _addon.setSetting('duuid',duuid)
    data = {'ident':ident,'wst': wst,'download_type':dtype,'device_uuid':duuid}
    #TODO password protect
    #response = api('file_protected',data) #protected
    #xml = ET.fromstring(response.content)
    #if is_ok(xml) and xml.find('protected').text != 0:
    #    pass #ask for password
    response = api('file_link',data)
    xml = ET.fromstring(response.content)
    if is_ok(xml):
        return xml.find('link').text
    else:
        popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
        return None

def play(params):
    token = revalidate()
    link = getlink(params['ident'],token)
    if link is not None:
        #headers experiment
        headers = _session.headers
        if headers:
            headers.update({'Cookie':'wst='+token})
            link = link + '|' + urlencode(headers)
        listitem = xbmcgui.ListItem(label=params['name'],path=link)
        listitem.setProperty('mimetype', 'application/octet-stream')
        xbmcplugin.setResolvedUrl(_handle, True, listitem)
    else:
        popinfo(_addon.getLocalizedString(30107), icon=xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())

def join(path, file):
    if path.endswith('/') or path.endswith('\\'):
        return path + file
    else:
        return path + '/' + file

def download(params):
    token = revalidate()
    where = _addon.getSetting('dfolder')
    if not where or not xbmcvfs.exists(where):
        popinfo('set folder!', sound=True)#_addon.getLocalizedString(30101)
        _addon.openSettings()
        return
        
    local = os.path.exists(where)
        
    normalize = 'true' == _addon.getSetting('dnormalize')
    notify = 'true' == _addon.getSetting('dnotify')
    every = _addon.getSetting('dnevery')
    try:
        every = int(re.sub(r'[^\d]+', '', every))
    except:
        every = 10
        
    try:
        link = getlink(params['ident'],token,'file_download')
        info = getinfo(params['ident'],token)
        name = info.find('name').text
        if normalize:
            name = unidecode.unidecode(name)
        bf = io.open(os.path.join(where,name), 'wb') if local else xbmcvfs.File(join(where,name), 'w')
        response = _session.get(link, stream=True)
        total = response.headers.get('content-length')
        if total is None:
            popinfo(_addon.getLocalizedString(30301) + name, icon=xbmcgui.NOTIFICATION_WARNING, sound=True)
            bf.write(response.content)
        elif not notify:
            popinfo(_addon.getLocalizedString(30302) + name)
            bf.write(response.content)
        else:
            popinfo(_addon.getLocalizedString(30302) + name)
            dl = 0
            total = int(total)
            pct = total / 100
            lastpop=0
            for data in response.iter_content(chunk_size=4096):
                dl += len(data)
                bf.write(data)
                done = int(dl / pct)
                if done % every == 0 and lastpop != done:
                    popinfo(str(done) + '% - ' + name)
                    lastpop = done
        bf.close()
        popinfo(_addon.getLocalizedString(30303) + name, sound=True)
    except Exception as e:
        #TODO - remove unfinished file?
        traceback.print_exc()
        popinfo(_addon.getLocalizedString(30304) + name, icon=xbmcgui.NOTIFICATION_ERROR, sound=True)

def loaddb(dbdir,file):
    try:
        data = {}
        with io.open(os.path.join(dbdir, file), 'r', encoding='utf8') as file:
            fdata = file.read()
            file.close()
            try:
                data = json.loads(fdata, "utf-8")['data']
            except TypeError:
                data = json.loads(fdata)['data']
        return data
    except Exception as e:
        traceback.print_exc()
        return {}

def db(params):
    token = revalidate()
    updateListing=False

    dbdir = os.path.join(_profile,'db')
    if not os.path.exists(dbdir):
        link = getlink(BACKUP_DB,token)
        dbfile = os.path.join(_profile,'db.zip')
        with io.open(dbfile, 'wb') as bf:
            response = _session.get(link, stream=True)
            bf.write(response.content)
            bf.flush()
            bf.close()
        with zipfile.ZipFile(dbfile, 'r') as zf:
            zf.extractall(_profile)
        os.unlink(dbfile)
    
    if 'toqueue' in params:
        toqueue(params['toqueue'],token)
        updateListing=True
    
    if 'file' in params and 'key' in params:
        data = loaddb(dbdir,params['file'])
        item = next((x for x in data if x['id'] == params['key']), None)
        if item is not None:
            for stream in item['streams']:
                commands = []
                commands.append(( _addon.getLocalizedString(30214), 'Container.Update(' + get_url(action='db',file=params['file'],key=params['key'],toqueue=stream['ident']) + ')'))
                listitem = tolistitem({'ident':stream['ident'],'name':stream['quality'] + ' - ' + stream['lang'] + stream['ainfo'],'sizelized':stream['size']},commands)
                xbmcplugin.addDirectoryItem(_handle, get_url(action='play',ident=stream['ident'],name=item['title']), listitem, False)
    elif 'file' in params:
        data = loaddb(dbdir,params['file'])
        for item in data:
            listitem = xbmcgui.ListItem(label=item['title'])
            if 'plot' in item:
                listitem.setInfo('video', {'title': item['title'],'plot': item['plot']})
            xbmcplugin.addDirectoryItem(_handle, get_url(action='db',file=params['file'],key=item['id']), listitem, True)
    else:
        if os.path.exists(dbdir):
            dbfiles = [f for f in os.listdir(dbdir) if os.path.isfile(os.path.join(dbdir, f))]
            for dbfile in dbfiles:
                listitem = xbmcgui.ListItem(label=os.path.splitext(dbfile)[0])
                xbmcplugin.addDirectoryItem(_handle, get_url(action='db',file=dbfile), listitem, True)
    xbmcplugin.addSortMethod(_handle,xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.endOfDirectory(_handle, updateListing=updateListing)

def menu():
    revalidate()
    xbmcplugin.setPluginCategory(_handle, _addon.getAddonInfo('name'))
    listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30201))
    listitem.setArt({'icon': 'DefaultAddonsSearch.png'})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='search'), listitem, True)
    
    listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30202))
    listitem.setArt({'icon': 'DefaultPlaylist.png'})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='queue'), listitem, True)
    
    listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30203))
    listitem.setArt({'icon': 'DefaultAddonsUpdates.png'})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='history'), listitem, True)
    
    # Add Series Manager menu item
    listitem = xbmcgui.ListItem(label='Serialy')
    listitem.setArt({'icon': 'DefaultTVShows.png'})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='series'), listitem, True)
    
    if 'true' == _addon.getSetting('experimental'):
        listitem = xbmcgui.ListItem(label='Backup DB')
        listitem.setArt({'icon': 'DefaultAddonsZip.png'})
        xbmcplugin.addDirectoryItem(_handle, get_url(action='db'), listitem, True)

    listitem = xbmcgui.ListItem(label=_addon.getLocalizedString(30204))
    listitem.setArt({'icon': 'DefaultAddonService.png'})
    xbmcplugin.addDirectoryItem(_handle, get_url(action='settings'), listitem, False)

    xbmcplugin.endOfDirectory(_handle)

def series_menu(params):
    """Handle Series functionality"""
    # Initialize SeriesManager
    sm = series_manager.SeriesManager(_addon, _profile)
    
    series_manager.create_series_menu(sm, _handle)

def series_search(params):
    """Search for a TV series and organize it into seasons and episodes"""
    token = revalidate()
    
    # Ask for series name
    series_name = ask(None)
    if not series_name:
        xbmcplugin.endOfDirectory(_handle, succeeded=False)
        return
    
    # Initialize SeriesManager and perform search
    sm = series_manager.SeriesManager(_addon, _profile)
    
    # Show progress dialog
    progress = xbmcgui.DialogProgress()
    progress.create('YaWSP', f'Vyhledavam serial {series_name}...')
    
    try:
        # Search for the series
        series_data = sm.search_series(series_name, api, token)
        
        if not series_data or not series_data['seasons']:
            progress.close()
            popinfo('Nenalezeny zadne epizody tohoto serialu', icon=xbmcgui.NOTIFICATION_WARNING)
            xbmcplugin.endOfDirectory(_handle, succeeded=False)
            return
        
        # Success
        progress.close()
        popinfo(f'Nalezeno {sum(len(season) for season in series_data["seasons"].values())} epizod v {len(series_data["seasons"])} sezonach')
        
        # Redirect to series detail
        xbmc.executebuiltin(f'Container.Update({get_url(action="series_detail", series_name=series_name)})')
        
    except Exception as e:
        progress.close()
        traceback.print_exc()
        popinfo(f'Chyba: {str(e)}', icon=xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle, succeeded=False)

def series_detail(params):
    """Show seasons for a series"""
    xbmcplugin.setPluginCategory(_handle, _addon.getAddonInfo('name') + " \ " + params['series_name'])
    
    # Initialize SeriesManager
    sm = series_manager.SeriesManager(_addon, _profile)
    
    # Display seasons menu
    series_manager.create_seasons_menu(sm, _handle, params['series_name'])

def series_season(params):
    """Show episodes for a season"""
    series_name = params['series_name']
    season = params['season']
    
    xbmcplugin.setPluginCategory(_handle, _addon.getAddonInfo('name') + " \ " + series_name + " \ " + f"Rada {season}")
    
    # Initialize SeriesManager
    sm = series_manager.SeriesManager(_addon, _profile)
    
    # Display episodes menu
    series_manager.create_episodes_menu(sm, _handle, series_name, season)

def series_refresh(params):
    """Refresh series data"""
    token = revalidate()
    series_name = params['series_name']
    
    # Initialize SeriesManager and perform search
    sm = series_manager.SeriesManager(_addon, _profile)
    
    # Show progress dialog
    progress = xbmcgui.DialogProgress()
    progress.create('YaWSP', f'Aktualizuji data pro serial {series_name}...')
    
    try:
        # Search for the series
        series_data = sm.search_series(series_name, api, token)
        
        if not series_data or not series_data['seasons']:
            progress.close()
            popinfo('Nenalezeny zadne epizody tohoto serialu', icon=xbmcgui.NOTIFICATION_WARNING)
            xbmcplugin.endOfDirectory(_handle, succeeded=False)
            return
        
        # Success
        progress.close()
        popinfo(f'Aktualizovano: {sum(len(season) for season in series_data["seasons"].values())} epizod v {len(series_data["seasons"])} sezonach')
        
        # Redirect to series detail to refresh the view
        xbmc.executebuiltin(f'Container.Update({get_url(action="series_detail", series_name=series_name)})')
        
    except Exception as e:
        progress.close()
        traceback.print_exc()
        popinfo(f'Chyba: {str(e)}', icon=xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle, succeeded=False)

def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if params:
        if params['action'] == 'search':
            search(params)
        elif params['action'] == 'queue':
            queue(params)
        elif params['action'] == 'history':
            history(params)
        elif params['action'] == 'settings':
            settings(params)
        elif params['action'] == 'info':
            info(params)
        elif params['action'] == 'play':
            play(params)
        elif params['action'] == 'download':
            download(params)
        elif params['action'] == 'db':
            db(params)
        # Series Manager actions
        elif params['action'] == 'series':
            series_menu(params)
        elif params['action'] == 'has_results':
            has_results_action(params)
        elif params['action'] == 'series_search':
            series_search(params)
        elif params['action'] == 'series_detail':
            series_detail(params)
        elif params['action'] == 'series_season':
            series_season(params)
        elif params['action'] == 'series_refresh':
            series_refresh(params)
        else:
            menu()
    else:
        menu()
